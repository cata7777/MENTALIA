#!/usr/bin/env python3
"""
CLUB ND - Comunidad Neurodivergente Integral
Plataforma de conexión y herramientas especializadas
Ecosistema MENTALIA
"""

import os
import sys
from flask import Flask, request, jsonify, render_template
from datetime import datetime
import json

# Configuración de la aplicación
app = Flask(__name__)
app.config['SECRET_KEY'] = 'club_nd_community_2025'

# Configuración de módulos especializados
app.config['MODULES'] = {
    'autorregulacion': 'Técnicas de autorregulación ND',
    'finanzas': 'Gestión financiera TDAH-friendly',
    'hogar': 'Organización del hogar sensorial',
    'gaming': 'Comunidad gamer ND',
    'comunicacion': 'Habilidades sociales ND',
    'mindfulness': 'Meditación adaptada ND',
    'brain_dump': 'Descarga mental organizada',
    'boleta_app': 'Gestión médica y síntomas'
}

class ClubNDCommunity:
    """Sistema principal de CLUB ND"""
    
    def __init__(self):
        self.members = []
        self.active_modules = []
        self.community_stats = {
            'total_members': 0,
            'active_today': 0,
            'modules_used': 0,
            'connections_made': 0
        }
    
    def register_member(self, member_data):
        """Registrar nuevo miembro de la comunidad"""
        member = {
            'id': len(self.members) + 1,
            'username': member_data.get('username'),
            'nd_profile': member_data.get('nd_profile'),
            'interests': member_data.get('interests', []),
            'joined_date': datetime.now().isoformat(),
            'modules_access': self.get_module_access(member_data.get('membership_type', 'basic'))
        }
        
        self.members.append(member)
        self.community_stats['total_members'] += 1
        return member
    
    def get_module_access(self, membership_type):
        """Determinar acceso a módulos según tipo de membresía"""
        if membership_type == 'premium':
            return list(app.config['MODULES'].keys())
        elif membership_type == 'professional':
            return list(app.config['MODULES'].keys()) + ['analytics', 'admin']
        else:  # basic
            return ['autorregulacion', 'comunicacion', 'mindfulness']
    
    def activate_module(self, member_id, module_name):
        """Activar módulo específico para un miembro"""
        module_session = {
            'member_id': member_id,
            'module': module_name,
            'started_at': datetime.now().isoformat(),
            'status': 'active'
        }
        
        self.active_modules.append(module_session)
        self.community_stats['modules_used'] += 1
        return module_session
    
    def get_community_feed(self):
        """Obtener feed de actividad de la comunidad"""
        return {
            'recent_activities': [
                {'type': 'new_member', 'message': 'Nuevo miembro se unió al club'},
                {'type': 'module_completion', 'message': 'Alguien completó el módulo de autorregulación'},
                {'type': 'community_challenge', 'message': 'Challenge semanal: Mindfulness ND'},
                {'type': 'success_story', 'message': 'Historia de éxito compartida en finanzas ND'}
            ],
            'stats': self.community_stats
        }
    
    def get_module_recommendations(self, member_id):
        """Obtener recomendaciones de módulos personalizadas"""
        # Aquí se integraría con BLU Supervisora y Perfil ND
        return {
            'recommended': ['autorregulacion', 'brain_dump'],
            'trending': ['gaming', 'finanzas'],
            'personalized': ['mindfulness', 'comunicacion']
        }

# Instancia global de la comunidad
club_community = ClubNDCommunity()

@app.route('/')
def home():
    """Página principal de CLUB ND"""
    return {
        'club': 'CLUB ND',
        'version': '2.0 MENTALIA',
        'status': 'ACTIVE',
        'community_size': club_community.community_stats['total_members'],
        'available_modules': list(app.config['MODULES'].keys()),
        'ecosystem': 'MENTALIA'
    }

@app.route('/api/join', methods=['POST'])
def join_club():
    """Unirse al CLUB ND"""
    try:
        member_data = request.get_json()
        new_member = club_community.register_member(member_data)
        
        return jsonify({
            'status': 'WELCOME_TO_CLUB',
            'member': new_member,
            'message': '¡Bienvenido/a a la comunidad ND!',
            'next_steps': [
                'Completa tu perfil ND',
                'Explora los módulos disponibles',
                'Conecta con otros miembros',
                'Participa en challenges'
            ]
        })
    
    except Exception as e:
        return jsonify({
            'status': 'ERROR',
            'message': str(e)
        }), 500

@app.route('/api/modules/<module_name>/activate', methods=['POST'])
def activate_module(module_name):
    """Activar módulo específico"""
    try:
        data = request.get_json()
        member_id = data.get('member_id')
        
        if module_name not in app.config['MODULES']:
            return jsonify({
                'status': 'ERROR',
                'message': 'Módulo no encontrado'
            }), 404
        
        session = club_community.activate_module(member_id, module_name)
        
        return jsonify({
            'status': 'MODULE_ACTIVATED',
            'session': session,
            'module_info': {
                'name': module_name,
                'description': app.config['MODULES'][module_name]
            }
        })
    
    except Exception as e:
        return jsonify({
            'status': 'ERROR',
            'message': str(e)
        }), 500

@app.route('/api/community/feed', methods=['GET'])
def get_community_feed():
    """Obtener feed de actividad comunitaria"""
    feed = club_community.get_community_feed()
    return jsonify(feed)

@app.route('/api/recommendations/<int:member_id>', methods=['GET'])
def get_recommendations(member_id):
    """Obtener recomendaciones personalizadas"""
    recommendations = club_community.get_module_recommendations(member_id)
    return jsonify({
        'member_id': member_id,
        'recommendations': recommendations,
        'integration': {
            'perfil_nd': 'Basado en tu perfil neurodivergente',
            'journaling': 'Según tus reflexiones recientes',
            'blu_supervisora': 'Análisis de bienestar actual'
        }
    })

@app.route('/api/modules', methods=['GET'])
def get_modules():
    """Obtener información de todos los módulos"""
    return jsonify({
        'modules': app.config['MODULES'],
        'total_modules': len(app.config['MODULES']),
        'categories': {
            'bienestar': ['autorregulacion', 'mindfulness'],
            'vida_practica': ['finanzas', 'hogar'],
            'social': ['comunicacion', 'gaming'],
            'herramientas': ['brain_dump', 'boleta_app']
        }
    })

if __name__ == '__main__':
    print("👥 CLUB ND - Comunidad activada")
    print("🧠 Módulos especializados: LISTOS")
    print("🤝 Conexión comunitaria: ACTIVA")
    print("🔗 Ecosistema MENTALIA: CONECTADO")
    
    app.run(host='0.0.0.0', port=5002, debug=True)

