# MODELOS_CLUB_ND.py - módulo CLUB_ND
