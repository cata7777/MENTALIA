
# 🔄 GENERADOR DE INFORME ND + ESTRATEGIAS PERSONALIZADAS

def generar_informe_nd(respuestas_bloques):
    perfil = []
    estrategias = []

    if respuestas_bloques.get("sensorial"):
        perfil.append("Rasgos de sensibilidad sensorial (auditiva, táctil o visual).")
        estrategias.append("Explora adaptaciones ambientales: auriculares, filtros de luz, ropa sin etiquetas.")

    if respuestas_bloques.get("cognitivo"):
        perfil.append("Estilo de pensamiento divergente, visual o monotrópico.")
        estrategias.append("Utiliza esquemas, mapas mentales o escritura libre simbólica.")

    if respuestas_bloques.get("emocional"):
        perfil.append("Alta sensibilidad emocional o dificultad en regulación.")
        estrategias.append("Practica journaling diario. Usa escalas del 1 al 10 para registrar intensidad.")

    if respuestas_bloques.get("interaccion"):
        perfil.append("Preferencia por interacción selectiva o dificultad con códigos sociales implícitos.")
        estrategias.append("Crea guiones sociales ND propios. Registra vínculos que no exigen camuflaje.")

    if respuestas_bloques.get("burnout"):
        perfil.append("Señales de burnout, masking prolongado o shutdowns.")
        estrategias.append("Diseña una rutina ND funcional. Registra señales de sobrecarga y activa pausas ND.")

    if respuestas_bloques.get("altas_capacidades"):
        perfil.append("Rasgos compatibles con alta capacidad o doble excepcionalidad.")
        estrategias.append("Divide metas ambiciosas en microtareas. Usa escritura creativa como descarga cognitiva.")

    resultado = {
        "perfil_descriptivo": perfil,
        "estrategias_personalizadas": estrategias,
        "nota": "Este informe no representa un diagnóstico. Es una exploración reflexiva sobre tu forma de ser y funcionar."
    }

    return resultado
