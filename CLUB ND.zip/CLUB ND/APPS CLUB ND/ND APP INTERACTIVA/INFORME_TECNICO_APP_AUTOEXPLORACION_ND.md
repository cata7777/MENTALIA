
# 🧠 INFORME TÉCNICO APP — GUÍA DE AUTOEXPLORACIÓN ND Y NEUROTIPOS COMBINADOS

## 📘 ORIGEN
Basado en el texto creado por Catalina Rojo Lema  
Versión clínico-terapéutica con enfoque neuroafirmativo, interseccional, con perspectiva de género.

---

## 🧠 ARQUITECTURA INTERACTIVA — BLOQUES DETECTADOS

1. Procesamiento Sensorial + Nutrición
2. Estilo de Pensamiento (monotrópico, divergente, visual, etc.)
3. Regulación Emocional y Crisis
4. Interacción Social Infantil y Adulta
5. Masking (Enmascaramiento)
6. Trauma, Burnout, Alexitimia
7. Alta Capacidad / Doble Excepcionalidad
8. Divergencia Atencional (TDAH)
9. Incongruencia Social / Ambigüedad Relacional
10. Identidad ND / Validación
11. Procesamiento Cognitivo No Convencional

---

## 🔁 MODOS DE USO

- Adulto/a/es: todos los bloques
- Adolescente: desde infancia hasta adolescencia
- Niños/as/es: infancia guiada por adultos responsables

---

## 🔓 SALIDA: PERFIL ND COMBINADO

- Análisis de múltiples rasgos ND simultáneos
- Configuración combinatoria: "CEA + TDAH + Alta Capacidad"
- Recomendaciones por capa
- Exportable (PDF, app, vinculación API con otros módulos ND)

---

## 🧰 TECNOLOGÍA RECOMENDADA

- Backend: Flask / FastAPI
- Frontend: React / Next.js
- Exportación: PDF / JSON
- Base de datos: PostgreSQL / Firebase
- Dashboard clínico (opcional): Grafana o Metabase

---

**Estado actual:** Evaluado y segmentado con protocolo CSMD  
**Siguiente fase:** Implementación modular + conexión con otros servicios ND

