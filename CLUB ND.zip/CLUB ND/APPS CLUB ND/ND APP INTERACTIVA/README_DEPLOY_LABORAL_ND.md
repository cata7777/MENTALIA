
# 🚀 README - DESPLIEGUE MÓDULO LABORAL ND

## 📦 SUBMÓDULOS INCLUIDOS
- CV ND
- MATCH ND
- FORMACIÓN LABORAL
- PLATAFORMA OTEC
- DISEÑA TU CURSO ND

---

## ⚙️ INSTALACIÓN

```bash
unzip MODULO_LABORAL_ND_COMPLETO.zip
pip install flask
```

---

## 🧩 INTEGRACIÓN

```python
from flask import Flask
from ENDPOINTS_CV_ND import cv_bp
from ENDPOINTS_MATCH_ND import match_bp
from ENDPOINTS_FORMACION_ND import formacion_bp
from ENDPOINTS_OTEC_ND import otec_bp
from ENDPOINTS_DISENA_CURSO_ND import disena_bp
from SSO_PERFIL_ND import perfil_bp

app = Flask(__name__)
app.register_blueprint(cv_bp)
app.register_blueprint(match_bp)
app.register_blueprint(formacion_bp)
app.register_blueprint(otec_bp)
app.register_blueprint(disena_bp)
app.register_blueprint(perfil_bp)
```

---

## 🚀 EJECUCIÓN LOCAL

```bash
export FLASK_APP=app.py
flask run
```

---

## 🌐 DEPLOY CLOUD

### Render o Railway:
- Conectar repo GitHub
- Command: `flask run`

### Docker AWS:
- Dockerfile → AWS ECS o Lightsail

---

**Versión:** Junio 2025  
**Autoridad:** Ecosistema ND / Manus AI  
**Estado:** Listo para Producción

