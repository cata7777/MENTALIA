import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Brain, 
  Zap, 
  Lightbulb, 
  Target, 
  Heart, 
  Sparkles, 
  Plus, 
  Trash2, 
  Edit, 
  Save, 
  Clock, 
  Calendar, 
  Tag, 
  Filter, 
  Search, 
  Download, 
  Upload, 
  Share, 
  Star, 
  Trophy, 
  Award, 
  CheckCircle, 
  Circle, 
  ArrowRight, 
  ArrowDown, 
  ArrowUp, 
  Shuffle, 
  RotateCcw, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Eye, 
  EyeOff, 
  Maximize, 
  Minimize, 
  Settings, 
  HelpCircle, 
  Info, 
  AlertCircle,
  Flame,
  Rocket,
  Stars,
  Palette,
  Music,
  Coffee,
  Book,
  Briefcase,
  Home,
  Users,
  MessageCircle,
  Phone,
  Mail,
  Camera,
  Image,
  Video,
  Mic,
  Headphones
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('volcado')
  const [currentThought, setCurrentThought] = useState('')
  const [thoughts, setThoughts] = useState([])
  const [categories, setCategories] = useState([
    { id: 'ideas', name: 'Ideas', color: 'bg-yellow-500', icon: '💡', count: 0 },
    { id: 'tareas', name: 'Tareas', color: 'bg-blue-500', icon: '✅', count: 0 },
    { id: 'emociones', name: 'Emociones', color: 'bg-pink-500', icon: '💜', count: 0 },
    { id: 'proyectos', name: 'Proyectos', color: 'bg-green-500', icon: '🚀', count: 0 },
    { id: 'preocupaciones', name: 'Preocupaciones', color: 'bg-red-500', icon: '😰', count: 0 },
    { id: 'inspiracion', name: 'Inspiración', color: 'bg-purple-500', icon: '✨', count: 0 },
    { id: 'recordatorios', name: 'Recordatorios', color: 'bg-orange-500', icon: '⏰', count: 0 },
    { id: 'random', name: 'Random', color: 'bg-gray-500', icon: '🎲', count: 0 }
  ])
  const [selectedCategory, setSelectedCategory] = useState('ideas')
  const [filterCategory, setFilterCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [isHyperfocusMode, setIsHyperfocusMode] = useState(false)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [dopamineScore, setDopamineScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [totalThoughts, setTotalThoughts] = useState(0)
  const [achievements, setAchievements] = useState([
    { id: 1, name: 'Primer Volcado', description: 'Registra tu primer pensamiento', unlocked: false, icon: '🎯' },
    { id: 2, name: 'Organizador Mental', description: 'Categoriza 10 pensamientos', unlocked: false, icon: '🧠' },
    { id: 3, name: 'Racha de Fuego', description: 'Volcado diario por 7 días', unlocked: false, icon: '🔥' },
    { id: 4, name: 'Maestro del Caos', description: 'Organiza 50 pensamientos', unlocked: false, icon: '🌟' },
    { id: 5, name: 'Hiperfoco Legendario', description: 'Usa modo hiperfoco 10 veces', unlocked: false, icon: '⚡' },
    { id: 6, name: 'Mente Brillante', description: 'Alcanza 1000 puntos de dopamina', unlocked: false, icon: '💎' }
  ])
  const [visualMode, setVisualMode] = useState('list')
  const [autoSave, setAutoSave] = useState(true)
  const [lastSaved, setLastSaved] = useState(new Date())

  const textareaRef = useRef(null)
  const [isTyping, setIsTyping] = useState(false)
  const [typingTimer, setTypingTimer] = useState(null)

  // Efectos de sonido y animaciones
  const playSound = (type) => {
    if (!soundEnabled) return
    // Simulación de sonidos
    console.log(`🔊 Sonido: ${type}`)
  }

  const addThought = () => {
    if (!currentThought.trim()) return

    const newThought = {
      id: Date.now(),
      content: currentThought,
      category: selectedCategory,
      timestamp: new Date(),
      priority: 'normal',
      completed: false,
      tags: extractTags(currentThought)
    }

    setThoughts(prev => [newThought, ...prev])
    setCurrentThought('')
    setTotalThoughts(prev => prev + 1)
    setDopamineScore(prev => prev + 10)
    
    // Actualizar contador de categoría
    setCategories(prev => prev.map(cat => 
      cat.id === selectedCategory 
        ? { ...cat, count: cat.count + 1 }
        : cat
    ))

    // Efectos de dopamina
    playSound('success')
    checkAchievements()
    
    // Auto-focus para siguiente pensamiento
    setTimeout(() => {
      textareaRef.current?.focus()
    }, 100)
  }

  const extractTags = (text) => {
    const tagRegex = /#(\w+)/g
    const matches = text.match(tagRegex)
    return matches ? matches.map(tag => tag.slice(1)) : []
  }

  const deleteThought = (id) => {
    const thought = thoughts.find(t => t.id === id)
    if (thought) {
      setCategories(prev => prev.map(cat => 
        cat.id === thought.category 
          ? { ...cat, count: Math.max(0, cat.count - 1) }
          : cat
      ))
    }
    setThoughts(prev => prev.filter(t => t.id !== id))
    playSound('delete')
  }

  const toggleComplete = (id) => {
    setThoughts(prev => prev.map(t => 
      t.id === id 
        ? { ...t, completed: !t.completed }
        : t
    ))
    setDopamineScore(prev => prev + 5)
    playSound('complete')
  }

  const checkAchievements = () => {
    setAchievements(prev => prev.map(achievement => {
      if (achievement.unlocked) return achievement

      let shouldUnlock = false
      switch (achievement.id) {
        case 1: shouldUnlock = totalThoughts >= 1; break
        case 2: shouldUnlock = totalThoughts >= 10; break
        case 3: shouldUnlock = streak >= 7; break
        case 4: shouldUnlock = totalThoughts >= 50; break
        case 5: shouldUnlock = false; break // Implementar contador hiperfoco
        case 6: shouldUnlock = dopamineScore >= 1000; break
      }

      if (shouldUnlock) {
        playSound('achievement')
        setDopamineScore(prev => prev + 50)
        return { ...achievement, unlocked: true }
      }
      return achievement
    }))
  }

  const filteredThoughts = thoughts.filter(thought => {
    const matchesCategory = filterCategory === 'all' || thought.category === filterCategory
    const matchesSearch = thought.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         thought.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const getCategoryById = (id) => categories.find(cat => cat.id === id)

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      addThought()
    }
  }

  const handleTyping = () => {
    setIsTyping(true)
    if (typingTimer) clearTimeout(typingTimer)
    setTypingTimer(setTimeout(() => setIsTyping(false), 1000))
  }

  useEffect(() => {
    if (autoSave) {
      const saveTimer = setTimeout(() => {
        setLastSaved(new Date())
      }, 2000)
      return () => clearTimeout(saveTimer)
    }
  }, [thoughts, autoSave])

  const formatTime = (date) => {
    return date.toLocaleTimeString('es-CL', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  const formatDate = (date) => {
    return date.toLocaleDateString('es-CL', { 
      day: '2-digit', 
      month: '2-digit',
      year: '2-digit'
    })
  }

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isHyperfocusMode 
        ? 'bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900' 
        : 'bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900'
    }`}>
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Brain className={`w-8 h-8 ${isHyperfocusMode ? 'text-purple-400' : 'text-indigo-400'} ${isTyping ? 'animate-pulse' : ''}`} />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className={`text-2xl font-bold bg-gradient-to-r ${
                  isHyperfocusMode 
                    ? 'from-purple-400 to-pink-400' 
                    : 'from-indigo-400 to-purple-400'
                } bg-clip-text text-transparent`}>
                  BRAIN DUMP ND
                </h1>
                <p className="text-xs text-gray-300">Volcado Mental Neurodivergente</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-purple-400 text-purple-400">
                <Flame className="w-3 h-3 mr-1" />
                {dopamineScore} pts
              </Badge>
              <Badge variant="outline" className="border-pink-400 text-pink-400">
                <Zap className="w-3 h-3 mr-1" />
                {streak} días
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsHyperfocusMode(!isHyperfocusMode)}
                className={isHyperfocusMode ? 'bg-purple-500/20' : ''}
              >
                <Target className="w-4 h-4" />
              </Button>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-white">Catalina Boetsch</p>
                  <p className="text-xs text-gray-400">TDAH + AC</p>
                </div>
                <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-lg">
                  🧠
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/20 backdrop-blur-md">
            <TabsTrigger value="volcado" className="data-[state=active]:bg-purple-500/20">
              <Brain className="w-4 h-4 mr-2" />
              Volcado
            </TabsTrigger>
            <TabsTrigger value="organizacion" className="data-[state=active]:bg-indigo-500/20">
              <Target className="w-4 h-4 mr-2" />
              Organización
            </TabsTrigger>
            <TabsTrigger value="visualizacion" className="data-[state=active]:bg-pink-500/20">
              <Eye className="w-4 h-4 mr-2" />
              Visualización
            </TabsTrigger>
            <TabsTrigger value="logros" className="data-[state=active]:bg-yellow-500/20">
              <Trophy className="w-4 h-4 mr-2" />
              Logros
            </TabsTrigger>
          </TabsList>

          {/* Volcado */}
          <TabsContent value="volcado" className="space-y-6 mt-6">
            {/* Área de Volcado Principal */}
            <Card className={`bg-black/20 backdrop-blur-md border-white/10 text-white ${
              isHyperfocusMode ? 'ring-2 ring-purple-500/50' : ''
            }`}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                    Volcado Mental Rápido
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-green-500/20 text-green-400">
                      {totalThoughts} pensamientos
                    </Badge>
                    {autoSave && (
                      <Badge className="bg-blue-500/20 text-blue-400">
                        <Save className="w-3 h-3 mr-1" />
                        Auto-guardado {formatTime(lastSaved)}
                      </Badge>
                    )}
                  </div>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  {isHyperfocusMode 
                    ? '🎯 MODO HIPERFOCO ACTIVADO - Concentración máxima'
                    : 'Vuelca todo lo que tienes en mente. Ctrl+Enter para agregar rápido.'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                  <div className="lg:col-span-3">
                    <Textarea
                      ref={textareaRef}
                      placeholder="¿Qué tienes en mente? Escribe todo lo que se te ocurra... Usa #tags para organizar automáticamente"
                      value={currentThought}
                      onChange={(e) => {
                        setCurrentThought(e.target.value)
                        handleTyping()
                      }}
                      onKeyDown={handleKeyPress}
                      className={`min-h-[120px] bg-gray-800/50 border-gray-700 text-white resize-none ${
                        isHyperfocusMode ? 'text-lg' : ''
                      }`}
                      autoFocus
                    />
                    <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
                      <span>{currentThought.length} caracteres</span>
                      <span>Ctrl+Enter para agregar</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="bg-gray-800/50 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.id}>
                            <div className="flex items-center space-x-2">
                              <span>{category.icon}</span>
                              <span>{category.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={addThought} 
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      disabled={!currentThought.trim()}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Volcar Pensamiento
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setCurrentThought('')}
                      className="w-full"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Limpiar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Categorías Rápidas */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Tag className="w-5 h-5 mr-2 text-blue-400" />
                  Categorías Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                  {categories.map(category => (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? 'default' : 'outline'}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`h-16 flex flex-col justify-center items-center ${
                        selectedCategory === category.id 
                          ? `${category.color}/20 border-2` 
                          : 'border-gray-600'
                      }`}
                    >
                      <div className="text-2xl mb-1">{category.icon}</div>
                      <span className="text-xs">{category.name}</span>
                      <Badge className="text-xs mt-1">{category.count}</Badge>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Pensamientos Recientes */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-green-400" />
                    Pensamientos Recientes
                  </div>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Buscar..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-48 bg-gray-800/50 border-gray-700"
                    />
                    <Select value={filterCategory} onValueChange={setFilterCategory}>
                      <SelectTrigger className="w-32 bg-gray-800/50 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todas</SelectItem>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {filteredThoughts.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No hay pensamientos que coincidan con tu búsqueda</p>
                    </div>
                  ) : (
                    filteredThoughts.map(thought => {
                      const category = getCategoryById(thought.category)
                      return (
                        <div key={thought.id} className={`p-4 rounded-lg border ${category.color}/20 border-gray-600`}>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="text-lg">{category.icon}</span>
                                <Badge className={`${category.color}/20 text-white`}>
                                  {category.name}
                                </Badge>
                                <span className="text-xs text-gray-400">
                                  {formatDate(thought.timestamp)} {formatTime(thought.timestamp)}
                                </span>
                              </div>
                              <p className={`text-white ${thought.completed ? 'line-through opacity-60' : ''}`}>
                                {thought.content}
                              </p>
                              {thought.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {thought.tags.map(tag => (
                                    <Badge key={tag} variant="outline" className="text-xs">
                                      #{tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center space-x-2 ml-4">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleComplete(thought.id)}
                              >
                                {thought.completed ? 
                                  <CheckCircle className="w-4 h-4 text-green-400" /> : 
                                  <Circle className="w-4 h-4" />
                                }
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteThought(thought.id)}
                              >
                                <Trash2 className="w-4 h-4 text-red-400" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Organización */}
          <TabsContent value="organizacion" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2 text-indigo-400" />
                  Organización Inteligente
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Visualiza y organiza tus pensamientos por categorías
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {categories.map(category => (
                    <div key={category.id} className={`p-6 rounded-lg border ${category.color}/20 border-gray-600`}>
                      <div className="text-center">
                        <div className="text-4xl mb-3">{category.icon}</div>
                        <h3 className="text-lg font-semibold text-white mb-2">{category.name}</h3>
                        <div className="text-3xl font-bold text-white mb-2">{category.count}</div>
                        <p className="text-sm text-gray-400">pensamientos</p>
                        <Progress 
                          value={(category.count / Math.max(totalThoughts, 1)) * 100} 
                          className="mt-3"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Visualización */}
          <TabsContent value="visualizacion" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="w-5 h-5 mr-2 text-pink-400" />
                  Mapa Mental Visual
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Visualización interactiva de tus pensamientos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Brain className="w-24 h-24 mx-auto mb-6 text-pink-400 opacity-50" />
                  <h3 className="text-xl font-semibold mb-4">Mapa Mental en Desarrollo</h3>
                  <p className="text-gray-400 mb-6">
                    Próximamente: Visualización interactiva de conexiones entre tus pensamientos
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-purple-900/20 rounded-lg">
                      <Sparkles className="w-8 h-8 mx-auto mb-2 text-purple-400" />
                      <p className="text-sm">Conexiones IA</p>
                    </div>
                    <div className="p-4 bg-blue-900/20 rounded-lg">
                      <Rocket className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                      <p className="text-sm">Clusters Temáticos</p>
                    </div>
                    <div className="p-4 bg-green-900/20 rounded-lg">
                      <Stars className="w-8 h-8 mx-auto mb-2 text-green-400" />
                      <p className="text-sm">Patrones Ocultos</p>
                    </div>
                    <div className="p-4 bg-yellow-900/20 rounded-lg">
                      <Palette className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                      <p className="text-sm">Vista 3D</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logros */}
          <TabsContent value="logros" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-yellow-400" />
                  Sistema de Logros Dopaminérgicos
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Recompensas diseñadas para mantener tu motivación ND
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {achievements.map(achievement => (
                    <div key={achievement.id} className={`p-6 rounded-lg border ${
                      achievement.unlocked 
                        ? 'bg-yellow-900/20 border-yellow-500/50' 
                        : 'bg-gray-900/20 border-gray-600'
                    }`}>
                      <div className="text-center">
                        <div className={`text-4xl mb-3 ${achievement.unlocked ? '' : 'grayscale opacity-50'}`}>
                          {achievement.icon}
                        </div>
                        <h3 className={`text-lg font-semibold mb-2 ${
                          achievement.unlocked ? 'text-yellow-400' : 'text-gray-500'
                        }`}>
                          {achievement.name}
                        </h3>
                        <p className="text-sm text-gray-400 mb-3">{achievement.description}</p>
                        {achievement.unlocked && (
                          <Badge className="bg-yellow-500/20 text-yellow-400">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            ¡Desbloqueado!
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <Brain className="w-6 h-6 text-purple-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
                BRAIN DUMP ND
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              Primera plataforma de volcado mental neurodivergente del mundo
            </p>
            <p className="text-gray-500 text-xs">
              Organiza el caos mental con dopamina, gamificación y herramientas adaptadas a tu neurotipo
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
              <span>© 2024 BRAIN DUMP ND</span>
              <span>•</span>
              <span>Desarrollado con 🧠 por Manolo</span>
              <span>•</span>
              <span>Para Cata y la comunidad ND</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

