import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { 
  Home, 
  Lightbulb, 
  Thermometer, 
  Wind, 
  Music, 
  Sun, 
  Moon, 
  Zap, 
  Brain, 
  Heart, 
  Sparkles, 
  Palette, 
  Waves, 
  TreePine, 
  Volume2, 
  VolumeX, 
  Lock, 
  Unlock, 
  Clock, 
  Calendar, 
  Users, 
  Settings, 
  Plus, 
  Minus, 
  Power, 
  PowerOff, 
  Bell, 
  AlertCircle, 
  CheckCircle, 
  Info, 
  HelpCircle, 
  SlidersHorizontal, 
  Droplets, 
  Sunrise, 
  Sunset, 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  CloudLightning
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedRoom, setSelectedRoom] = useState('sala_estar')
  const [rooms, setRooms] = useState({
    sala_estar: {
      nombre: 'Sala de Estar',
      icono: '🛋️',
      iluminacion: { encendida: true, brillo: 80, color: '#FFDAB9' },
      clima: { encendido: true, temperatura: 22, modo: 'frío' },
      sonido: { encendido: true, playlist: 'Calma Sensorial', volumen: 40 },
      ambiente: 'Relajación',
      dispositivos: 4,
      consumo: 1.2
    },
    dormitorio: {
      nombre: 'Dormitorio',
      icono: '🛏️',
      iluminacion: { encendida: false, brillo: 60, color: '#E6E6FA' },
      clima: { encendido: false, temperatura: 20, modo: 'frío' },
      sonido: { encendido: false, playlist: 'Sueño Profundo', volumen: 30 },
      ambiente: 'Descanso',
      dispositivos: 3,
      consumo: 0.8
    },
    oficina: {
      nombre: 'Oficina',
      icono: '💻',
      iluminacion: { encendida: true, brillo: 100, color: '#ADD8E6' },
      clima: { encendido: true, temperatura: 23, modo: 'frío' },
      sonido: { encendido: true, playlist: 'Hiperfoco', volumen: 60 },
      ambiente: 'Concentración',
      dispositivos: 5,
      consumo: 1.8
    },
    espacio_calma: {
      nombre: 'Espacio de Calma',
      icono: '🧘‍♀️',
      iluminacion: { encendida: true, brillo: 50, color: '#98FB98' },
      clima: { encendido: true, temperatura: 21, modo: 'ventilador' },
      sonido: { encendido: true, playlist: 'Sonidos de la Naturaleza', volumen: 50 },
      ambiente: 'Regulación',
      dispositivos: 2,
      consumo: 0.6
    }
  })

  const [ambientes, setAmbientes] = useState({
    concentracion: {
      nombre: 'Concentración',
      icono: '🎯',
      color: 'from-blue-500 to-cyan-500',
      configuracion: {
        iluminacion: { brillo: 100, color: '#ADD8E6' },
        clima: { temperatura: 23, modo: 'frío' },
        sonido: { playlist: 'Hiperfoco', volumen: 60 }
      }
    },
    relajacion: {
      nombre: 'Relajación',
      icono: '🛀',
      color: 'from-purple-500 to-pink-500',
      configuracion: {
        iluminacion: { brillo: 80, color: '#FFDAB9' },
        clima: { temperatura: 22, modo: 'frío' },
        sonido: { playlist: 'Calma Sensorial', volumen: 40 }
      }
    },
    energia: {
      nombre: 'Energía',
      icono: '⚡',
      color: 'from-yellow-500 to-orange-500',
      configuracion: {
        iluminacion: { brillo: 120, color: '#FFFFE0' },
        clima: { temperatura: 24, modo: 'frío' },
        sonido: { playlist: 'Ritmos Energéticos', volumen: 70 }
      }
    },
    descanso: {
      nombre: 'Descanso',
      icono: '😴',
      color: 'from-indigo-500 to-purple-500',
      configuracion: {
        iluminacion: { brillo: 60, color: '#E6E6FA' },
        clima: { temperatura: 20, modo: 'frío' },
        sonido: { playlist: 'Sueño Profundo', volumen: 30 }
      }
    },
    regulacion: {
      nombre: 'Regulación',
      icono: '🧘‍♀️',
      color: 'from-green-500 to-teal-500',
      configuracion: {
        iluminacion: { brillo: 50, color: '#98FB98' },
        clima: { temperatura: 21, modo: 'ventilador' },
        sonido: { playlist: 'Sonidos de la Naturaleza', volumen: 50 }
      }
    }
  })

  const [rutinas, setRutinas] = useState([
    {
      id: 1,
      nombre: 'Rutina de Mañana',
      icono: '🌅',
      hora: '07:00',
      dias: ['L', 'M', 'X', 'J', 'V'],
      activa: true,
      acciones: [
        { habitacion: 'dormitorio', dispositivo: 'iluminacion', accion: 'encender', valor: { brillo: 80, color: '#FFFFE0' } },
        { habitacion: 'dormitorio', dispositivo: 'sonido', accion: 'reproducir', valor: { playlist: 'Despertar Suave', volumen: 40 } },
        { habitacion: 'sala_estar', dispositivo: 'clima', accion: 'encender', valor: { temperatura: 22, modo: 'frío' } }
      ]
    },
    {
      id: 2,
      nombre: 'Rutina de Concentración',
      icono: '🎯',
      hora: '10:00',
      dias: ['L', 'M', 'X', 'J', 'V'],
      activa: true,
      acciones: [
        { habitacion: 'oficina', dispositivo: 'ambiente', accion: 'activar', valor: 'Concentración' }
      ]
    },
    {
      id: 3,
      nombre: 'Rutina de Noche',
      icono: '🌃',
      hora: '22:00',
      dias: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
      activa: true,
      acciones: [
        { habitacion: 'dormitorio', dispositivo: 'ambiente', accion: 'activar', valor: 'Descanso' },
        { habitacion: 'sala_estar', dispositivo: 'iluminacion', accion: 'apagar' }
      ]
    }
  ])

  const [notificaciones, setNotificaciones] = useState([
    { id: 1, texto: 'El filtro de aire de la oficina necesita ser reemplazado.', tipo: 'alerta', leida: false },
    { id: 2, texto: 'Se ha activado la rutina de mañana.', tipo: 'info', leida: true },
    { id: 3, texto: 'Consumo de energía un 15% más alto que ayer.', tipo: 'alerta', leida: false }
  ])

  const handleRoomControl = (room, device, key, value) => {
    setRooms(prevRooms => ({
      ...prevRooms,
      [room]: {
        ...prevRooms[room],
        [device]: {
          ...prevRooms[room][device],
          [key]: value
        }
      }
    }))
  }

  const handleActivateAmbiente = (room, ambiente) => {
    const ambienteConfig = ambientes[ambiente.toLowerCase()].configuracion
    setRooms(prevRooms => ({
      ...prevRooms,
      [room]: {
        ...prevRooms[room],
        iluminacion: { ...prevRooms[room].iluminacion, ...ambienteConfig.iluminacion, encendida: true },
        clima: { ...prevRooms[room].clima, ...ambienteConfig.clima, encendido: true },
        sonido: { ...prevRooms[room].sonido, ...ambienteConfig.sonido, encendido: true },
        ambiente: ambiente
      }
    }))
  }

  const formatNumber = (num) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k'
    }
    return num.toString()
  }

  const totalConsumo = Object.values(rooms).reduce((acc, room) => acc + room.consumo, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Home className="w-8 h-8 text-blue-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-indigo-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
                  HOGAR ND
                </h1>
                <p className="text-xs text-gray-300">Espacios Sensoriales Inteligentes</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-blue-400 text-blue-400">
                <Zap className="w-3 h-3 mr-1" />
                {totalConsumo.toFixed(1)} kWh
              </Badge>
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-300 cursor-pointer hover:text-blue-400" />
                {notificaciones.filter(n => !n.leida).length > 0 && (
                  <div className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white">
                    {notificaciones.filter(n => !n.leida).length}
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-white">Catalina Boetsch</p>
                  <p className="text-xs text-gray-400">Propietaria</p>
                </div>
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-lg">
                  🦋
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/20 backdrop-blur-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-blue-500/20">
              <Home className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="habitaciones" className="data-[state=active]:bg-indigo-500/20">
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Habitaciones
            </TabsTrigger>
            <TabsTrigger value="ambientes" className="data-[state=active]:bg-purple-500/20">
              <Sparkles className="w-4 h-4 mr-2" />
              Ambientes
            </TabsTrigger>
            <TabsTrigger value="rutinas" className="data-[state=active]:bg-pink-500/20">
              <Calendar className="w-4 h-4 mr-2" />
              Rutinas
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(rooms).map(([key, room]) => (
                <Card key={key} className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="text-2xl mr-2">{room.icono}</div>
                        {room.nombre}
                      </div>
                      <Switch 
                        checked={room.iluminacion.encendida || room.clima.encendido || room.sonido.encendido}
                        onCheckedChange={(checked) => {
                          handleRoomControl(key, 'iluminacion', 'encendida', checked)
                          handleRoomControl(key, 'clima', 'encendido', checked)
                          handleRoomControl(key, 'sonido', 'encendido', checked)
                        }}
                      />
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-400">
                        <Lightbulb className="w-4 h-4 mr-1" />
                        <span>Iluminación</span>
                      </div>
                      <span className={room.iluminacion.encendida ? 'text-blue-400' : 'text-gray-500'}>
                        {room.iluminacion.encendida ? `${room.iluminacion.brillo}%` : 'Apagada'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-400">
                        <Thermometer className="w-4 h-4 mr-1" />
                        <span>Clima</span>
                      </div>
                      <span className={room.clima.encendido ? 'text-blue-400' : 'text-gray-500'}>
                        {room.clima.encendido ? `${room.clima.temperatura}°C` : 'Apagado'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-400">
                        <Music className="w-4 h-4 mr-1" />
                        <span>Sonido</span>
                      </div>
                      <span className={room.sonido.encendido ? 'text-blue-400' : 'text-gray-500'}>
                        {room.sonido.encendido ? `${room.sonido.volumen}%` : 'Apagado'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-3 border-t border-white/10">
                      <div className="flex items-center text-gray-400">
                        <Sparkles className="w-4 h-4 mr-1" />
                        <span>Ambiente</span>
                      </div>
                      <span className="text-purple-400">{room.ambiente}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Ambientes Rápidos */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Sparkles className="w-5 h-5 mr-2 text-purple-400" />
                    Ambientes Rápidos
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Activa un ambiente en la habitación actual: {rooms[selectedRoom].nombre}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.values(ambientes).map((ambiente) => (
                      <Button 
                        key={ambiente.nombre} 
                        className={`h-20 flex flex-col justify-center items-center bg-gradient-to-br ${ambiente.color}/20 border border-purple-500/20`}
                        onClick={() => handleActivateAmbiente(selectedRoom, ambiente.nombre)}
                      >
                        <div className="text-2xl mb-1">{ambiente.icono}</div>
                        <span className="text-sm">{ambiente.nombre}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Rutinas Activas */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-pink-400" />
                    Rutinas Activas
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Automatizaciones para tu hogar neurodivergente
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {rutinas.map((rutina) => (
                    <div key={rutina.id} className="flex items-center justify-between p-3 bg-pink-900/20 rounded-lg border border-pink-500/20">
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{rutina.icono}</div>
                        <div>
                          <h4 className="font-medium text-pink-400">{rutina.nombre}</h4>
                          <p className="text-xs text-gray-400">{rutina.hora} - {rutina.dias.join(', ')}</p>
                        </div>
                      </div>
                      <Switch checked={rutina.activa} onCheckedChange={(checked) => {
                        setRutinas(prev => prev.map(r => r.id === rutina.id ? { ...r, activa: checked } : r))
                      }} />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Habitaciones */}
          <TabsContent value="habitaciones" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <SlidersHorizontal className="w-5 h-5 mr-2 text-indigo-400" />
                  Control de Habitaciones
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Selecciona una habitación para controlar sus dispositivos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4 mb-6">
                  {Object.entries(rooms).map(([key, room]) => (
                    <Button
                      key={key}
                      variant={selectedRoom === key ? 'default' : 'outline'}
                      onClick={() => setSelectedRoom(key)}
                      className={selectedRoom === key ? 'bg-indigo-500/20 text-indigo-400' : 'border-indigo-500/50 text-indigo-400'}
                    >
                      <div className="text-lg mr-2">{room.icono}</div>
                      {room.nombre}
                    </Button>
                  ))}
                </div>

                {selectedRoom && (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Iluminación */}
                    <div className="bg-indigo-900/20 p-6 rounded-lg border border-indigo-500/20">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-indigo-400 flex items-center">
                          <Lightbulb className="w-5 h-5 mr-2" />
                          Iluminación
                        </h3>
                        <Switch 
                          checked={rooms[selectedRoom].iluminacion.encendida}
                          onCheckedChange={(checked) => handleRoomControl(selectedRoom, 'iluminacion', 'encendida', checked)}
                        />
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-400">Brillo</label>
                          <Slider 
                            value={[rooms[selectedRoom].iluminacion.brillo]} 
                            onValueChange={([value]) => handleRoomControl(selectedRoom, 'iluminacion', 'brillo', value)}
                            disabled={!rooms[selectedRoom].iluminacion.encendida}
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">Color</label>
                          <input 
                            type="color" 
                            value={rooms[selectedRoom].iluminacion.color} 
                            onChange={(e) => handleRoomControl(selectedRoom, 'iluminacion', 'color', e.target.value)}
                            className="w-full h-10 p-1 bg-gray-800 border border-gray-700 rounded-lg"
                            disabled={!rooms[selectedRoom].iluminacion.encendida}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Clima */}
                    <div className="bg-indigo-900/20 p-6 rounded-lg border border-indigo-500/20">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-indigo-400 flex items-center">
                          <Thermometer className="w-5 h-5 mr-2" />
                          Clima
                        </h3>
                        <Switch 
                          checked={rooms[selectedRoom].clima.encendido}
                          onCheckedChange={(checked) => handleRoomControl(selectedRoom, 'clima', 'encendido', checked)}
                        />
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-400">Temperatura</label>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" onClick={() => handleRoomControl(selectedRoom, 'clima', 'temperatura', rooms[selectedRoom].clima.temperatura - 1)} disabled={!rooms[selectedRoom].clima.encendido}>-</Button>
                            <span className="text-lg font-bold w-12 text-center">{rooms[selectedRoom].clima.temperatura}°C</span>
                            <Button size="sm" onClick={() => handleRoomControl(selectedRoom, 'clima', 'temperatura', rooms[selectedRoom].clima.temperatura + 1)} disabled={!rooms[selectedRoom].clima.encendido}>+</Button>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">Modo</label>
                          <Select 
                            value={rooms[selectedRoom].clima.modo} 
                            onValueChange={(value) => handleRoomControl(selectedRoom, 'clima', 'modo', value)}
                            disabled={!rooms[selectedRoom].clima.encendido}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="frío">Frío</SelectItem>
                              <SelectItem value="calor">Calor</SelectItem>
                              <SelectItem value="ventilador">Ventilador</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Sonido */}
                    <div className="bg-indigo-900/20 p-6 rounded-lg border border-indigo-500/20">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-indigo-400 flex items-center">
                          <Music className="w-5 h-5 mr-2" />
                          Sonido
                        </h3>
                        <Switch 
                          checked={rooms[selectedRoom].sonido.encendido}
                          onCheckedChange={(checked) => handleRoomControl(selectedRoom, 'sonido', 'encendido', checked)}
                        />
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-400">Volumen</label>
                          <Slider 
                            value={[rooms[selectedRoom].sonido.volumen]} 
                            onValueChange={([value]) => handleRoomControl(selectedRoom, 'sonido', 'volumen', value)}
                            disabled={!rooms[selectedRoom].sonido.encendido}
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">Playlist</label>
                          <Select 
                            value={rooms[selectedRoom].sonido.playlist} 
                            onValueChange={(value) => handleRoomControl(selectedRoom, 'sonido', 'playlist', value)}
                            disabled={!rooms[selectedRoom].sonido.encendido}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Calma Sensorial">Calma Sensorial</SelectItem>
                              <SelectItem value="Sueño Profundo">Sueño Profundo</SelectItem>
                              <SelectItem value="Hiperfoco">Hiperfoco</SelectItem>
                              <SelectItem value="Sonidos de la Naturaleza">Sonidos de la Naturaleza</SelectItem>
                              <SelectItem value="Ritmos Energéticos">Ritmos Energéticos</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ambientes */}
          <TabsContent value="ambientes" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Sparkles className="w-5 h-5 mr-2 text-purple-400" />
                  Gestión de Ambientes
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Crea y personaliza tus ambientes sensoriales
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Object.values(ambientes).map((ambiente) => (
                    <div key={ambiente.nombre} className={`bg-gradient-to-br ${ambiente.color}/20 p-6 rounded-lg border border-purple-500/20`}>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-3xl">{ambiente.icono}</div>
                          <h3 className="text-lg font-semibold">{ambiente.nombre}</h3>
                        </div>
                        <Button size="sm" variant="ghost"><Settings className="w-4 h-4" /></Button>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Iluminación:</span>
                          <span className="text-white">{ambiente.configuracion.iluminacion.brillo}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Clima:</span>
                          <span className="text-white">{ambiente.configuracion.clima.temperatura}°C</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Sonido:</span>
                          <span className="text-white">{ambiente.configuracion.sonido.playlist}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button className="h-full flex flex-col justify-center items-center bg-purple-900/20 border border-dashed border-purple-500/50">
                    <Plus className="w-8 h-8 mb-2" />
                    Crear Nuevo Ambiente
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Rutinas */}
          <TabsContent value="rutinas" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-pink-400" />
                  Gestión de Rutinas
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Automatiza tu hogar para un día a día más fácil
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {rutinas.map((rutina) => (
                    <div key={rutina.id} className="bg-pink-900/20 p-6 rounded-lg border border-pink-500/20">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-3xl">{rutina.icono}</div>
                          <div>
                            <h3 className="text-lg font-semibold text-pink-400">{rutina.nombre}</h3>
                            <p className="text-sm text-gray-400">{rutina.hora} - {rutina.dias.join(', ')}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch checked={rutina.activa} onCheckedChange={(checked) => {
                            setRutinas(prev => prev.map(r => r.id === rutina.id ? { ...r, activa: checked } : r))
                          }} />
                          <Button size="sm" variant="ghost"><Settings className="w-4 h-4" /></Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-gray-400">Acciones:</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {rutina.acciones.map((accion, index) => (
                            <div key={index} className="bg-gray-800/50 p-2 rounded-md text-xs">
                              <p className="font-semibold capitalize">{accion.habitacion.replace('_', ' ')}</p>
                              <p className="text-gray-300 capitalize">{accion.dispositivo}: {accion.accion}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button className="w-full h-20 flex justify-center items-center bg-pink-900/20 border border-dashed border-pink-500/50">
                    <Plus className="w-6 h-6 mr-2" />
                    Crear Nueva Rutina
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <Home className="w-6 h-6 text-blue-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
                HOGAR ND
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              Primera plataforma de espacios sensoriales inteligentes para neurodivergencia
            </p>
            <p className="text-gray-500 text-xs">
              Creando hogares que cuidan de ti, adaptados a tu neurotipo
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
              <span>© 2024 HOGAR ND</span>
              <span>•</span>
              <span>Desarrollado con 🏠 por Manolo</span>
              <span>•</span>
              <span>Para Cata y la comunidad ND</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

