import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Heart, 
  Brain, 
  Leaf, 
  Sun, 
  Moon, 
  Wind, 
  Waves, 
  Mountain,
  Flower,
  TreePine,
  Cloud,
  Star,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Timer,
  RotateCcw,
  Zap,
  Target,
  TrendingUp,
  Calendar,
  Award,
  Users,
  Settings,
  Sparkles,
  Flame,
  Snowflake,
  Droplets,
  Eye,
  EyeOff,
  Headphones,
  Music,
  Bell,
  CheckCircle,
  Circle,
  BarChart3,
  Activity,
  Smile,
  Frown,
  Meh,
  Angry,
  AlertTriangle,
  Shield,
  Flower2
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedNeurotipo, setSelectedNeurotipo] = useState('tdah')
  const [currentMeditation, setCurrentMeditation] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [meditationTime, setMeditationTime] = useState(0)
  const [selectedDuration, setSelectedDuration] = useState(10)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [currentMood, setCurrentMood] = useState('neutral')
  const [breathingPhase, setBreathingPhase] = useState('inhale') // inhale, hold, exhale
  const [breathingCount, setBreathingCount] = useState(0)

  // Simulación de meditación en progreso
  useEffect(() => {
    let interval = null
    if (isPlaying && currentMeditation) {
      interval = setInterval(() => {
        setMeditationTime(time => {
          if (time >= selectedDuration * 60) {
            setIsPlaying(false)
            return selectedDuration * 60
          }
          return time + 1
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, currentMeditation, selectedDuration])

  // Ejercicio de respiración automático
  useEffect(() => {
    if (activeTab === 'respiracion') {
      const breathingInterval = setInterval(() => {
        setBreathingCount(count => {
          const newCount = count + 1
          const cycle = newCount % 12 // 4 segundos inhalar, 4 mantener, 4 exhalar
          if (cycle <= 4) setBreathingPhase('inhale')
          else if (cycle <= 8) setBreathingPhase('hold')
          else setBreathingPhase('exhale')
          return newCount
        })
      }, 1000)
      return () => clearInterval(breathingInterval)
    }
  }, [activeTab])

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // Estadísticas del dashboard
  const dashboardStats = {
    sesionesCompletadas: 47,
    minutosTotal: 892,
    rachaActual: 12,
    nivelBienestar: 8.4,
    meditacionesFavoritas: 15,
    progresoSemanal: 85
  }

  // Meditaciones por neurotipo
  const meditacionesPorNeurotipo = {
    tdah: [
      {
        id: 1,
        titulo: 'Foco y Atención TDAH',
        descripcion: 'Meditación específica para mejorar la concentración',
        duracion: '10-20 min',
        tipo: 'Concentración',
        instructor: 'Dra. María Paz',
        dificultad: 'Principiante',
        rating: 4.8,
        completadas: 156,
        icono: <Target className="w-6 h-6" />,
        color: 'from-red-500 to-orange-500'
      },
      {
        id: 2,
        titulo: 'Calma para Hiperactividad',
        descripcion: 'Técnicas para reducir la inquietud y ansiedad',
        duracion: '5-15 min',
        tipo: 'Relajación',
        instructor: 'Lic. Carlos Ruiz',
        dificultad: 'Intermedio',
        rating: 4.9,
        completadas: 203,
        icono: <Waves className="w-6 h-6" />,
        color: 'from-blue-500 to-cyan-500'
      },
      {
        id: 3,
        titulo: 'Gestión de Impulsos',
        descripcion: 'Mindfulness para el control de impulsos',
        duracion: '8-12 min',
        tipo: 'Autocontrol',
        instructor: 'Dr. Luis Fernández',
        dificultad: 'Avanzado',
        rating: 4.7,
        completadas: 89,
        icono: <Zap className="w-6 h-6" />,
        color: 'from-yellow-500 to-red-500'
      }
    ],
    autismo: [
      {
        id: 4,
        titulo: 'Regulación Sensorial',
        descripcion: 'Meditación para sobrecarga sensorial',
        duracion: '15-25 min',
        tipo: 'Sensorial',
        instructor: 'Dra. Ana López',
        dificultad: 'Principiante',
        rating: 4.9,
        completadas: 134,
        icono: <Eye className="w-6 h-6" />,
        color: 'from-purple-500 to-blue-500'
      },
      {
        id: 5,
        titulo: 'Rutinas de Calma',
        descripcion: 'Secuencias predecibles para la tranquilidad',
        duracion: '10-20 min',
        tipo: 'Rutinas',
        instructor: 'Lic. Sofia Chen',
        dificultad: 'Principiante',
        rating: 4.8,
        completadas: 178,
        icono: <Mountain className="w-6 h-6" />,
        color: 'from-green-500 to-teal-500'
      },
      {
        id: 6,
        titulo: 'Comunicación Interna',
        descripcion: 'Conexión con emociones y necesidades',
        duracion: '12-18 min',
        tipo: 'Autoconocimiento',
        instructor: 'Dr. Pedro Martín',
        dificultad: 'Intermedio',
        rating: 4.6,
        completadas: 92,
        icono: <Heart className="w-6 h-6" />,
        color: 'from-pink-500 to-purple-500'
      }
    ],
    altasCapacidades: [
      {
        id: 7,
        titulo: 'Mente Acelerada',
        descripcion: 'Calma para pensamientos rápidos e intensos',
        duracion: '15-30 min',
        tipo: 'Mental',
        instructor: 'Dra. Elena Vargas',
        dificultad: 'Avanzado',
        rating: 4.9,
        completadas: 67,
        icono: <Brain className="w-6 h-6" />,
        color: 'from-indigo-500 to-purple-500'
      },
      {
        id: 8,
        titulo: 'Perfeccionismo Saludable',
        descripcion: 'Liberación de la presión por la perfección',
        duracion: '10-20 min',
        tipo: 'Autocompasión',
        instructor: 'Dr. Roberto Silva',
        dificultad: 'Intermedio',
        rating: 4.8,
        completadas: 45,
        icono: <Star className="w-6 h-6" />,
        color: 'from-yellow-500 to-orange-500'
      },
      {
        id: 9,
        titulo: 'Creatividad Consciente',
        descripcion: 'Mindfulness para potenciar la creatividad',
        duracion: '20-35 min',
        tipo: 'Creatividad',
        instructor: 'Dra. Carmen Torres',
        dificultad: 'Avanzado',
        rating: 4.7,
        completadas: 38,
        icono: <Sparkles className="w-6 h-6" />,
        color: 'from-pink-500 to-yellow-500'
      }
    ]
  }

  // Estados de ánimo
  const estadosAnimo = [
    { nombre: 'Ansioso', icono: <AlertTriangle className="w-6 h-6" />, color: 'text-red-400', id: 'ansioso' },
    { nombre: 'Estresado', icono: <Frown className="w-6 h-6" />, color: 'text-orange-400', id: 'estresado' },
    { nombre: 'Neutral', icono: <Meh className="w-6 h-6" />, color: 'text-gray-400', id: 'neutral' },
    { nombre: 'Tranquilo', icono: <Shield className="w-6 h-6" />, color: 'text-blue-400', id: 'tranquilo' },
    { nombre: 'Feliz', icono: <Smile className="w-6 h-6" />, color: 'text-green-400', id: 'feliz' },
    { nombre: 'Energético', icono: <Zap className="w-6 h-6" />, color: 'text-yellow-400', id: 'energetico' }
  ]

  // Técnicas de respiración
  const tecnicasRespiracion = [
    {
      nombre: '4-7-8 Relajante',
      descripcion: 'Inhala 4, mantén 7, exhala 8 segundos',
      patron: [4, 7, 8],
      beneficio: 'Reduce ansiedad y estrés'
    },
    {
      nombre: '4-4-4 Equilibrio',
      descripcion: 'Respiración cuadrada para TDAH',
      patron: [4, 4, 4],
      beneficio: 'Mejora concentración'
    },
    {
      nombre: '6-2-6 Suave',
      descripcion: 'Respiración gentil para sensibilidad',
      patron: [6, 2, 6],
      beneficio: 'Calma sobrecarga sensorial'
    }
  ]

  // Logros de bienestar
  const logrosBienestar = [
    { nombre: 'Primera Meditación', descripcion: 'Completaste tu primera sesión', icono: '🧘‍♀️', desbloqueado: true },
    { nombre: 'Racha de 7 días', descripcion: 'Meditaste 7 días consecutivos', icono: '🔥', desbloqueado: true },
    { nombre: 'Maestro del Mindfulness', descripcion: '50 sesiones completadas', icono: '🏆', desbloqueado: false },
    { nombre: 'Explorador ND', descripcion: 'Probaste los 3 neurotipos', icono: '🧭', desbloqueado: true },
    { nombre: 'Zen Master', descripcion: '100 horas de meditación', icono: '☯️', desbloqueado: false },
    { nombre: 'Guía Comunitario', descripcion: 'Ayudaste a 10 personas', icono: '👥', desbloqueado: false }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Leaf className="w-8 h-8 text-emerald-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                  MINDFULNESS ND
                </h1>
                <p className="text-xs text-gray-300">Bienestar y Meditación Neuroafirmativa</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-emerald-400 text-emerald-400">
                <Heart className="w-3 h-3 mr-1" />
                Zen Mode
              </Badge>
              <div className="text-right">
                <p className="text-sm font-medium text-white">Catalina Boetsch</p>
                <p className="text-xs text-gray-400">Nivel Bienestar: {dashboardStats.nivelBienestar}/10</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navegación */}
      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-black/20 backdrop-blur-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-emerald-500/20">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="meditaciones" className="data-[state=active]:bg-teal-500/20">
              <Brain className="w-4 h-4 mr-2" />
              Meditaciones
            </TabsTrigger>
            <TabsTrigger value="respiracion" className="data-[state=active]:bg-cyan-500/20">
              <Wind className="w-4 h-4 mr-2" />
              Respiración
            </TabsTrigger>
            <TabsTrigger value="estado" className="data-[state=active]:bg-blue-500/20">
              <Heart className="w-4 h-4 mr-2" />
              Estado
            </TabsTrigger>
            <TabsTrigger value="progreso" className="data-[state=active]:bg-purple-500/20">
              <TrendingUp className="w-4 h-4 mr-2" />
              Progreso
            </TabsTrigger>
            <TabsTrigger value="comunidad" className="data-[state=active]:bg-pink-500/20">
              <Users className="w-4 h-4 mr-2" />
              Comunidad
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Estadísticas de Bienestar */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="w-5 h-5 mr-2 text-emerald-400" />
                    Bienestar General
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-emerald-400">{dashboardStats.nivelBienestar}</p>
                    <p className="text-sm text-gray-400">Nivel de Bienestar</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-xl font-bold text-teal-400">{dashboardStats.sesionesCompletadas}</p>
                      <p className="text-xs text-gray-400">Sesiones</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-cyan-400">{dashboardStats.rachaActual}</p>
                      <p className="text-xs text-gray-400">Racha (días)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tiempo de Meditación */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Timer className="w-5 h-5 mr-2 text-blue-400" />
                    Tiempo de Práctica
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-blue-400">{dashboardStats.minutosTotal}</p>
                    <p className="text-sm text-gray-400">Minutos totales</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progreso semanal</span>
                      <span>{dashboardStats.progresoSemanal}%</span>
                    </div>
                    <Progress value={dashboardStats.progresoSemanal} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* Estado Actual */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="w-5 h-5 mr-2 text-pink-400" />
                    Estado Actual
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl mb-2">🧘‍♀️</div>
                    <p className="text-lg font-medium text-pink-400">Tranquilo</p>
                    <p className="text-sm text-gray-400">Última actualización: hace 2h</p>
                  </div>
                  <Button 
                    size="sm" 
                    className="w-full bg-pink-500/20 text-pink-400 hover:bg-pink-500/30"
                    onClick={() => setActiveTab('estado')}
                  >
                    Actualizar Estado
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Meditaciones Recomendadas */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Sparkles className="w-5 h-5 mr-2 text-yellow-400" />
                  Meditaciones Recomendadas para Ti
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Basado en tu perfil neurodivergente y estado actual
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {meditacionesPorNeurotipo.tdah.slice(0, 3).map((meditacion) => (
                    <div key={meditacion.id} className={`bg-gradient-to-br ${meditacion.color}/20 p-4 rounded-lg border border-emerald-500/20`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-emerald-400">{meditacion.icono}</div>
                        <Badge className="bg-emerald-500/20 text-emerald-400">{meditacion.tipo}</Badge>
                      </div>
                      <h3 className="font-medium mb-2">{meditacion.titulo}</h3>
                      <p className="text-xs text-gray-400 mb-3">{meditacion.descripcion}</p>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-xs text-gray-400">{meditacion.duracion}</span>
                        <div className="flex items-center text-yellow-400">
                          <Star className="w-3 h-3 mr-1" />
                          <span className="text-xs">{meditacion.rating}</span>
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                        onClick={() => {
                          setCurrentMeditation(meditacion)
                          setActiveTab('meditaciones')
                        }}
                      >
                        <Play className="w-3 h-3 mr-1" />
                        Comenzar
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ejercicio de Respiración Rápido */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Wind className="w-5 h-5 mr-2 text-cyan-400" />
                  Respiración Rápida
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Ejercicio de 2 minutos para calmar la mente
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center space-x-8">
                  <div className="text-center">
                    <div className={`w-20 h-20 rounded-full border-4 border-cyan-400 flex items-center justify-center transition-all duration-1000 ${
                      breathingPhase === 'inhale' ? 'scale-110 bg-cyan-400/20' :
                      breathingPhase === 'hold' ? 'scale-105 bg-blue-400/20' :
                      'scale-95 bg-teal-400/20'
                    }`}>
                      <Wind className="w-8 h-8 text-cyan-400" />
                    </div>
                    <p className="text-sm mt-2 text-cyan-400 capitalize">{breathingPhase}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg text-gray-300">
                      {breathingPhase === 'inhale' && 'Inhala profundamente...'}
                      {breathingPhase === 'hold' && 'Mantén la respiración...'}
                      {breathingPhase === 'exhale' && 'Exhala lentamente...'}
                    </p>
                    <Button 
                      size="sm" 
                      className="mt-2 bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                      onClick={() => setActiveTab('respiracion')}
                    >
                      Sesión Completa
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Meditaciones */}
          <TabsContent value="meditaciones" className="space-y-6 mt-6">
            {/* Selector de Neurotipo */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Meditaciones por Neurotipo
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Selecciona tu neurotipo para meditaciones especializadas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4 mb-6">
                  <Button
                    variant={selectedNeurotipo === 'tdah' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('tdah')}
                    className={selectedNeurotipo === 'tdah' ? 'bg-red-500/20 text-red-400' : 'border-red-500/50 text-red-400'}
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    TDAH
                  </Button>
                  <Button
                    variant={selectedNeurotipo === 'autismo' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('autismo')}
                    className={selectedNeurotipo === 'autismo' ? 'bg-blue-500/20 text-blue-400' : 'border-blue-500/50 text-blue-400'}
                  >
                    <Mountain className="w-4 h-4 mr-2" />
                    Autismo
                  </Button>
                  <Button
                    variant={selectedNeurotipo === 'altasCapacidades' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('altasCapacidades')}
                    className={selectedNeurotipo === 'altasCapacidades' ? 'bg-yellow-500/20 text-yellow-400' : 'border-yellow-500/50 text-yellow-400'}
                  >
                    <Star className="w-4 h-4 mr-2" />
                    Altas Capacidades
                  </Button>
                </div>

                {/* Lista de Meditaciones */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {meditacionesPorNeurotipo[selectedNeurotipo].map((meditacion) => (
                    <div key={meditacion.id} className={`bg-gradient-to-br ${meditacion.color}/20 p-6 rounded-lg border border-emerald-500/20`}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-emerald-400">{meditacion.icono}</div>
                          <div>
                            <h3 className="text-lg font-semibold">{meditacion.titulo}</h3>
                            <p className="text-sm text-gray-400">{meditacion.descripcion}</p>
                          </div>
                        </div>
                        <div className="flex items-center text-yellow-400">
                          <Star className="w-4 h-4 mr-1" />
                          <span className="text-sm">{meditacion.rating}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <Badge className="bg-emerald-500/20 text-emerald-400">{meditacion.tipo}</Badge>
                          <Badge variant="outline" className="border-gray-500 text-gray-400">{meditacion.dificultad}</Badge>
                        </div>
                        
                        <div className="flex justify-between text-sm text-gray-400">
                          <span>Duración: {meditacion.duracion}</span>
                          <span>{meditacion.completadas} completadas</span>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-500">Instructor: {meditacion.instructor}</span>
                          <Button 
                            size="sm" 
                            className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                            onClick={() => setCurrentMeditation(meditacion)}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Reproducir
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Reproductor de Meditación */}
            {currentMeditation && (
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Music className="w-5 h-5 mr-2 text-green-400" />
                    Reproductor de Meditación
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="text-center">
                      <h3 className="text-xl font-semibold mb-2">{currentMeditation.titulo}</h3>
                      <p className="text-gray-400 mb-4">{currentMeditation.descripcion}</p>
                      <div className="text-4xl font-mono text-green-400">
                        {formatTime(meditationTime)} / {formatTime(selectedDuration * 60)}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <Progress value={(meditationTime / (selectedDuration * 60)) * 100} className="h-2" />
                      
                      <div className="flex justify-center space-x-4">
                        <Button
                          size="sm"
                          onClick={() => setMeditationTime(Math.max(0, meditationTime - 30))}
                          className="bg-gray-500/20 text-gray-400 hover:bg-gray-500/30"
                        >
                          <SkipBack className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => setIsPlaying(!isPlaying)}
                          className="bg-green-500/20 text-green-400 hover:bg-green-500/30"
                        >
                          {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => setMeditationTime(Math.min(selectedDuration * 60, meditationTime + 30))}
                          className="bg-gray-500/20 text-gray-400 hover:bg-gray-500/30"
                        >
                          <SkipForward className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex justify-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-400">Duración:</span>
                          {[5, 10, 15, 20, 30].map(duration => (
                            <Button
                              key={duration}
                              size="sm"
                              variant={selectedDuration === duration ? 'default' : 'outline'}
                              onClick={() => setSelectedDuration(duration)}
                              className={selectedDuration === duration ? 'bg-green-500/20 text-green-400' : 'border-green-500/50 text-green-400'}
                            >
                              {duration}m
                            </Button>
                          ))}
                        </div>
                        <Button
                          size="sm"
                          onClick={() => setSoundEnabled(!soundEnabled)}
                          className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30"
                        >
                          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Respiración */}
          <TabsContent value="respiracion" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Wind className="w-5 h-5 mr-2 text-cyan-400" />
                  Ejercicios de Respiración ND
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Técnicas de respiración adaptadas para neurodivergencia
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {tecnicasRespiracion.map((tecnica, index) => (
                    <div key={index} className="bg-gradient-to-br from-cyan-900/20 to-blue-900/20 p-6 rounded-lg border border-cyan-500/20">
                      <h3 className="text-lg font-semibold mb-2 text-cyan-400">{tecnica.nombre}</h3>
                      <p className="text-sm text-gray-400 mb-3">{tecnica.descripcion}</p>
                      <p className="text-xs text-cyan-300 mb-4">{tecnica.beneficio}</p>
                      <Button 
                        size="sm" 
                        className="w-full bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Practicar
                      </Button>
                    </div>
                  ))}
                </div>

                {/* Visualizador de Respiración */}
                <div className="mt-8 text-center">
                  <div className="flex items-center justify-center mb-6">
                    <div className={`w-32 h-32 rounded-full border-4 border-cyan-400 flex items-center justify-center transition-all duration-1000 ${
                      breathingPhase === 'inhale' ? 'scale-125 bg-cyan-400/30' :
                      breathingPhase === 'hold' ? 'scale-110 bg-blue-400/30' :
                      'scale-90 bg-teal-400/30'
                    }`}>
                      <Wind className="w-12 h-12 text-cyan-400" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-semibold text-cyan-400 capitalize">
                      {breathingPhase === 'inhale' && 'Inhala'}
                      {breathingPhase === 'hold' && 'Mantén'}
                      {breathingPhase === 'exhale' && 'Exhala'}
                    </p>
                    <p className="text-gray-400">
                      {breathingPhase === 'inhale' && 'Respira profundamente por la nariz'}
                      {breathingPhase === 'hold' && 'Mantén el aire en tus pulmones'}
                      {breathingPhase === 'exhale' && 'Suelta el aire lentamente por la boca'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Estado */}
          <TabsContent value="estado" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="w-5 h-5 mr-2 text-pink-400" />
                  ¿Cómo te sientes ahora?
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Registra tu estado emocional para recibir recomendaciones personalizadas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {estadosAnimo.map((estado) => (
                    <button
                      key={estado.id}
                      onClick={() => setCurrentMood(estado.id)}
                      className={`p-4 rounded-lg border transition-all ${
                        currentMood === estado.id 
                          ? 'border-pink-500 bg-pink-500/20' 
                          : 'border-gray-500/20 bg-gray-900/20 hover:border-pink-500/50'
                      }`}
                    >
                      <div className={`${estado.color} mb-2 flex justify-center`}>
                        {estado.icono}
                      </div>
                      <p className="text-sm font-medium">{estado.nombre}</p>
                    </button>
                  ))}
                </div>

                {currentMood && (
                  <div className="mt-6 p-4 bg-pink-900/20 rounded-lg border border-pink-500/20">
                    <h3 className="text-lg font-semibold mb-2 text-pink-400">Recomendaciones para ti</h3>
                    <div className="space-y-2">
                      {currentMood === 'ansioso' && (
                        <>
                          <p className="text-sm text-gray-300">• Prueba la respiración 4-7-8 para calmar la ansiedad</p>
                          <p className="text-sm text-gray-300">• Meditación "Calma para Hiperactividad" recomendada</p>
                        </>
                      )}
                      {currentMood === 'estresado' && (
                        <>
                          <p className="text-sm text-gray-300">• Sesión de 10 minutos de mindfulness</p>
                          <p className="text-sm text-gray-300">• Ejercicio de respiración cuadrada</p>
                        </>
                      )}
                      {currentMood === 'tranquilo' && (
                        <>
                          <p className="text-sm text-gray-300">• Perfecto momento para meditación profunda</p>
                          <p className="text-sm text-gray-300">• Prueba "Creatividad Consciente"</p>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Progreso */}
          <TabsContent value="progreso" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Estadísticas Detalladas */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                    Estadísticas de Progreso
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { metrica: 'Nivel de Calma', valor: '8.4/10', cambio: '+0.7', color: 'text-emerald-400' },
                    { metrica: 'Frecuencia Semanal', valor: '5.2 días', cambio: '+1.1', color: 'text-blue-400' },
                    { metrica: 'Duración Promedio', valor: '18.9 min', cambio: '+3.2', color: 'text-purple-400' },
                    { metrica: 'Consistencia', valor: '87%', cambio: '+12%', color: 'text-yellow-400' }
                  ].map((stat, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-900/20 rounded-lg">
                      <span className="text-sm text-gray-300">{stat.metrica}</span>
                      <div className="text-right">
                        <p className={`font-semibold ${stat.color}`}>{stat.valor}</p>
                        <p className="text-xs text-green-400">+{stat.cambio}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Logros */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2 text-orange-400" />
                    Logros de Bienestar
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {logrosBienestar.map((logro, index) => (
                      <div key={index} className={`flex items-center space-x-3 p-3 rounded-lg ${
                        logro.desbloqueado ? 'bg-orange-900/20 border border-orange-500/20' : 'bg-gray-900/20 border border-gray-500/20'
                      }`}>
                        <div className={`text-2xl ${logro.desbloqueado ? '' : 'grayscale opacity-50'}`}>
                          {logro.icono}
                        </div>
                        <div className="flex-1">
                          <h4 className={`font-medium ${logro.desbloqueado ? 'text-orange-400' : 'text-gray-500'}`}>
                            {logro.nombre}
                          </h4>
                          <p className={`text-xs ${logro.desbloqueado ? 'text-gray-300' : 'text-gray-500'}`}>
                            {logro.descripcion}
                          </p>
                        </div>
                        {logro.desbloqueado && (
                          <CheckCircle className="w-5 h-5 text-orange-400" />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Comunidad */}
          <TabsContent value="comunidad" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-pink-400" />
                  Comunidad de Bienestar ND
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Conecta con otros practicantes neurodivergentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Círculos de Meditación</h3>
                    {[
                      { nombre: 'TDAH Mindfulness', miembros: 34, activo: true, tipo: 'TDAH' },
                      { nombre: 'Autismo Zen', miembros: 28, activo: true, tipo: 'Autismo' },
                      { nombre: 'AC Creatividad', miembros: 19, activo: false, tipo: 'Altas Capacidades' }
                    ].map((circulo, index) => (
                      <div key={index} className="bg-pink-900/20 p-4 rounded-lg border border-pink-500/20">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium">{circulo.nombre}</h4>
                            <p className="text-sm text-gray-400">{circulo.miembros} miembros • {circulo.tipo}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${circulo.activo ? 'bg-green-400' : 'bg-gray-400'}`}></div>
                            <Button size="sm" className="bg-pink-500/20 text-pink-400 hover:bg-pink-500/30">
                              Unirse
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Guías de Bienestar</h3>
                    {[
                      { nombre: 'Dra. María Paz', especialidad: 'Mindfulness TDAH', rating: 4.9, sesiones: 156 },
                      { nombre: 'Lic. Ana López', especialidad: 'Meditación Autismo', rating: 4.8, sesiones: 134 },
                      { nombre: 'Dr. Roberto Silva', especialidad: 'Bienestar AC', rating: 4.7, sesiones: 89 }
                    ].map((guia, index) => (
                      <div key={index} className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/20">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium">{guia.nombre}</h4>
                            <p className="text-sm text-gray-400">{guia.especialidad}</p>
                            <div className="flex items-center mt-1">
                              <Star className="w-3 h-3 text-yellow-400 mr-1" />
                              <span className="text-xs text-yellow-400">{guia.rating}</span>
                              <span className="text-xs text-gray-500 ml-2">• {guia.sesiones} sesiones</span>
                            </div>
                          </div>
                          <Button size="sm" className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30">
                            Contactar
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <Leaf className="w-6 h-6 text-emerald-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                MINDFULNESS ND
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              Primera plataforma de bienestar y meditación neuroafirmativa
            </p>
            <p className="text-gray-500 text-xs">
              Cultivando la paz interior en la comunidad neurodivergente
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
              <span>© 2024 MINDFULNESS ND</span>
              <span>•</span>
              <span>Desarrollado con 💚 por Manolo</span>
              <span>•</span>
              <span>Para Cata y la comunidad ND</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

