import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  PiggyBank, 
  CreditCard, 
  Target, 
  Brain, 
  Zap, 
  Heart, 
  Sparkles, 
  Calendar, 
  Clock, 
  Plus, 
  Minus, 
  ArrowUp, 
  ArrowDown, 
  Eye, 
  EyeOff, 
  Settings, 
  Bell, 
  Award, 
  Trophy, 
  Star, 
  CheckCircle, 
  AlertCircle, 
  Info, 
  HelpCircle,
  BarChart3,
  PieChart,
  LineChart,
  Wallet,
  ShoppingCart,
  Home,
  Car,
  Gamepad2,
  Coffee,
  Book,
  Music,
  Plane,
  Gift
} from 'lucide-react'
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Cell, BarChart as RechartsBarChart, Bar } from 'recharts'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [showBalance, setShowBalance] = useState(true)
  const [selectedPeriod, setSelectedPeriod] = useState('mes')

  // Datos financieros simulados
  const [finanzas, setFinanzas] = useState({
    balance: 2847.50,
    ingresos: 3200.00,
    gastos: 2156.30,
    ahorros: 1043.70,
    meta_ahorro: 1500.00,
    presupuesto_mensual: 2800.00
  })

  const [categorias, setCategorias] = useState([
    { nombre: 'Alimentación', presupuesto: 600, gastado: 487.30, color: '#FF6B6B', icono: '🍽️' },
    { nombre: 'Transporte', presupuesto: 300, gastado: 245.80, color: '#4ECDC4', icono: '🚗' },
    { nombre: 'Entretenimiento', presupuesto: 200, gastado: 156.90, color: '#45B7D1', icono: '🎮' },
    { nombre: 'Salud', presupuesto: 400, gastado: 320.50, color: '#96CEB4', icono: '💊' },
    { nombre: 'Educación', presupuesto: 250, gastado: 189.20, color: '#FFEAA7', icono: '📚' },
    { nombre: 'Hogar', presupuesto: 500, gastado: 412.60, color: '#DDA0DD', icono: '🏠' },
    { nombre: 'Ropa', presupuesto: 150, gastado: 98.40, color: '#FFB6C1', icono: '👕' },
    { nombre: 'Otros', presupuesto: 100, gastado: 245.60, color: '#F0E68C', icono: '📦' }
  ])

  const [transacciones, setTransacciones] = useState([
    { id: 1, fecha: '2024-06-28', descripcion: 'Salario', categoria: 'Ingresos', monto: 3200.00, tipo: 'ingreso' },
    { id: 2, fecha: '2024-06-27', descripcion: 'Supermercado', categoria: 'Alimentación', monto: -89.50, tipo: 'gasto' },
    { id: 3, fecha: '2024-06-26', descripcion: 'Netflix', categoria: 'Entretenimiento', monto: -15.99, tipo: 'gasto' },
    { id: 4, fecha: '2024-06-25', descripcion: 'Gasolina', categoria: 'Transporte', monto: -65.00, tipo: 'gasto' },
    { id: 5, fecha: '2024-06-24', descripcion: 'Farmacia', categoria: 'Salud', monto: -45.30, tipo: 'gasto' },
    { id: 6, fecha: '2024-06-23', descripcion: 'Curso Online', categoria: 'Educación', monto: -89.99, tipo: 'gasto' },
    { id: 7, fecha: '2024-06-22', descripcion: 'Ahorro Automático', categoria: 'Ahorros', monto: -200.00, tipo: 'ahorro' },
    { id: 8, fecha: '2024-06-21', descripcion: 'Freelance', categoria: 'Ingresos', monto: 450.00, tipo: 'ingreso' }
  ])

  const [metas, setMetas] = useState([
    { id: 1, nombre: 'Fondo de Emergencia', objetivo: 5000, actual: 2847.50, fecha_limite: '2024-12-31', prioridad: 'alta' },
    { id: 2, nombre: 'Vacaciones 2025', objetivo: 2000, actual: 650.00, fecha_limite: '2025-06-01', prioridad: 'media' },
    { id: 3, nombre: 'Laptop Nueva', objetivo: 1500, actual: 890.30, fecha_limite: '2024-09-15', prioridad: 'alta' },
    { id: 4, nombre: 'Curso Especialización', objetivo: 800, actual: 320.00, fecha_limite: '2024-08-30', prioridad: 'media' }
  ])

  const [configuracionND, setConfiguracionND] = useState({
    neurotipo: 'TDAH + Altas Capacidades',
    notificaciones_gamificadas: true,
    ahorro_automatico: true,
    recordatorios_gastos: true,
    modo_hiperfoco: false,
    alertas_sensoriales: true
  })

  // Datos para gráficos
  const datosGastosMensuales = [
    { mes: 'Ene', gastos: 2100, ingresos: 3200 },
    { mes: 'Feb', gastos: 1950, ingresos: 3200 },
    { mes: 'Mar', gastos: 2300, ingresos: 3200 },
    { mes: 'Abr', gastos: 2050, ingresos: 3200 },
    { mes: 'May', gastos: 2200, ingresos: 3200 },
    { mes: 'Jun', gastos: 2156, ingresos: 3200 }
  ]

  const datosDistribucionGastos = categorias.map(cat => ({
    name: cat.nombre,
    value: cat.gastado,
    color: cat.color
  }))

  const logros = [
    { id: 1, nombre: 'Ahorrador Constante', descripcion: '7 días seguidos ahorrando', desbloqueado: true, icono: '🏆' },
    { id: 2, nombre: 'Presupuesto Maestro', descripcion: 'No exceder presupuesto por 30 días', desbloqueado: false, icono: '🎯' },
    { id: 3, nombre: 'Meta Alcanzada', descripcion: 'Completar primera meta de ahorro', desbloqueado: true, icono: '⭐' },
    { id: 4, nombre: 'Hiperfoco Financiero', descripcion: 'Revisar finanzas 5 días seguidos', desbloqueado: true, icono: '🧠' }
  ]

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP'
    }).format(amount)
  }

  const getProgressColor = (percentage) => {
    if (percentage <= 50) return 'bg-green-500'
    if (percentage <= 80) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const getPriorityColor = (prioridad) => {
    switch (prioridad) {
      case 'alta': return 'bg-red-500'
      case 'media': return 'bg-yellow-500'
      case 'baja': return 'bg-green-500'
      default: return 'bg-gray-500'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900 to-emerald-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <DollarSign className="w-8 h-8 text-green-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                  FINANZAS ND
                </h1>
                <p className="text-xs text-gray-300">Gestión Financiera Neurodivergente</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-green-400 text-green-400">
                <TrendingUp className="w-3 h-3 mr-1" />
                +{((finanzas.ingresos - finanzas.gastos) / finanzas.ingresos * 100).toFixed(1)}%
              </Badge>
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-300 cursor-pointer hover:text-green-400" />
                <div className="absolute -top-2 -right-2 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-xs text-white">
                  3
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm font-medium text-white">Catalina Boetsch</p>
                  <p className="text-xs text-gray-400">{configuracionND.neurotipo}</p>
                </div>
                <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center text-lg">
                  💰
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-black/20 backdrop-blur-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-green-500/20">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="presupuesto" className="data-[state=active]:bg-emerald-500/20">
              <PieChart className="w-4 h-4 mr-2" />
              Presupuesto
            </TabsTrigger>
            <TabsTrigger value="metas" className="data-[state=active]:bg-teal-500/20">
              <Target className="w-4 h-4 mr-2" />
              Metas
            </TabsTrigger>
            <TabsTrigger value="transacciones" className="data-[state=active]:bg-cyan-500/20">
              <CreditCard className="w-4 h-4 mr-2" />
              Transacciones
            </TabsTrigger>
            <TabsTrigger value="logros" className="data-[state=active]:bg-blue-500/20">
              <Trophy className="w-4 h-4 mr-2" />
              Logros ND
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            {/* Resumen Financiero */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Balance Total</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowBalance(!showBalance)}
                  >
                    {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-400">
                    {showBalance ? formatCurrency(finanzas.balance) : '••••••'}
                  </div>
                  <p className="text-xs text-gray-400">
                    +{((finanzas.balance / finanzas.ingresos) * 100).toFixed(1)}% vs mes anterior
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ingresos</CardTitle>
                  <TrendingUp className="w-4 h-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-400">
                    {formatCurrency(finanzas.ingresos)}
                  </div>
                  <p className="text-xs text-gray-400">
                    Este mes
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Gastos</CardTitle>
                  <TrendingDown className="w-4 h-4 text-red-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-400">
                    {formatCurrency(finanzas.gastos)}
                  </div>
                  <p className="text-xs text-gray-400">
                    {((finanzas.gastos / finanzas.presupuesto_mensual) * 100).toFixed(1)}% del presupuesto
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ahorros</CardTitle>
                  <PiggyBank className="w-4 h-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-400">
                    {formatCurrency(finanzas.ahorros)}
                  </div>
                  <p className="text-xs text-gray-400">
                    {((finanzas.ahorros / finanzas.meta_ahorro) * 100).toFixed(1)}% de la meta
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de Gastos vs Ingresos */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <LineChart className="w-5 h-5 mr-2 text-green-400" />
                    Flujo de Efectivo
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Ingresos vs Gastos - Últimos 6 meses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsLineChart data={datosGastosMensuales}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="mes" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                      <Line type="monotone" dataKey="ingresos" stroke="#10B981" strokeWidth={3} />
                      <Line type="monotone" dataKey="gastos" stroke="#EF4444" strokeWidth={3} />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Distribución de Gastos */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChart className="w-5 h-5 mr-2 text-emerald-400" />
                    Distribución de Gastos
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Por categorías - Este mes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Pie
                        data={datosDistribucionGastos}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {datosDistribucionGastos.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Configuración ND */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Configuración Neurodivergente
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Personalización para {configuracionND.neurotipo}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center justify-between p-3 bg-purple-900/20 rounded-lg border border-purple-500/20">
                    <div className="flex items-center space-x-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span className="text-sm">Gamificación</span>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${configuracionND.notificaciones_gamificadas ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-900/20 rounded-lg border border-blue-500/20">
                    <div className="flex items-center space-x-2">
                      <PiggyBank className="w-4 h-4 text-blue-400" />
                      <span className="text-sm">Ahorro Auto</span>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${configuracionND.ahorro_automatico ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-900/20 rounded-lg border border-yellow-500/20">
                    <div className="flex items-center space-x-2">
                      <Bell className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm">Recordatorios</span>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${configuracionND.recordatorios_gastos ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-red-900/20 rounded-lg border border-red-500/20">
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-red-400" />
                      <span className="text-sm">Modo Hiperfoco</span>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${configuracionND.modo_hiperfoco ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-500/20">
                    <div className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-green-400" />
                      <span className="text-sm">Alertas Sensoriales</span>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${configuracionND.alertas_sensoriales ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Presupuesto */}
          <TabsContent value="presupuesto" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="w-5 h-5 mr-2 text-emerald-400" />
                  Control de Presupuesto por Categorías
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Gestión adaptada para neurodivergencia
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categorias.map((categoria, index) => {
                    const porcentaje = (categoria.gastado / categoria.presupuesto) * 100
                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="text-2xl">{categoria.icono}</span>
                            <span className="font-medium">{categoria.nombre}</span>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-bold">
                              {formatCurrency(categoria.gastado)} / {formatCurrency(categoria.presupuesto)}
                            </div>
                            <div className="text-xs text-gray-400">
                              {porcentaje.toFixed(1)}% usado
                            </div>
                          </div>
                        </div>
                        <Progress 
                          value={porcentaje} 
                          className="h-3"
                          style={{ 
                            '--progress-background': categoria.color,
                            backgroundColor: `${categoria.color}20`
                          }}
                        />
                        {porcentaje > 90 && (
                          <div className="flex items-center space-x-1 text-red-400 text-xs">
                            <AlertCircle className="w-3 h-3" />
                            <span>¡Presupuesto casi agotado!</span>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Metas */}
          <TabsContent value="metas" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2 text-teal-400" />
                  Metas de Ahorro
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Objetivos financieros con gamificación ND
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {metas.map((meta) => {
                    const porcentaje = (meta.actual / meta.objetivo) * 100
                    return (
                      <div key={meta.id} className="bg-teal-900/20 p-6 rounded-lg border border-teal-500/20">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-teal-400">{meta.nombre}</h3>
                          <Badge className={`${getPriorityColor(meta.prioridad)} text-white`}>
                            {meta.prioridad}
                          </Badge>
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span>Progreso:</span>
                            <span>{formatCurrency(meta.actual)} / {formatCurrency(meta.objetivo)}</span>
                          </div>
                          <Progress value={porcentaje} className="h-3" />
                          <div className="flex justify-between text-xs text-gray-400">
                            <span>{porcentaje.toFixed(1)}% completado</span>
                            <span>Fecha límite: {meta.fecha_limite}</span>
                          </div>
                          {porcentaje >= 100 && (
                            <div className="flex items-center space-x-1 text-green-400 text-sm">
                              <CheckCircle className="w-4 h-4" />
                              <span>¡Meta alcanzada!</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transacciones */}
          <TabsContent value="transacciones" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="w-5 h-5 mr-2 text-cyan-400" />
                  Historial de Transacciones
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Registro detallado de movimientos financieros
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {transacciones.map((transaccion) => (
                    <div key={transaccion.id} className="flex items-center justify-between p-4 bg-cyan-900/20 rounded-lg border border-cyan-500/20">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          transaccion.tipo === 'ingreso' ? 'bg-green-500/20 text-green-400' :
                          transaccion.tipo === 'ahorro' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {transaccion.tipo === 'ingreso' ? <ArrowUp className="w-5 h-5" /> :
                           transaccion.tipo === 'ahorro' ? <PiggyBank className="w-5 h-5" /> :
                           <ArrowDown className="w-5 h-5" />}
                        </div>
                        <div>
                          <p className="font-medium">{transaccion.descripcion}</p>
                          <p className="text-sm text-gray-400">{transaccion.categoria} • {transaccion.fecha}</p>
                        </div>
                      </div>
                      <div className={`text-lg font-bold ${
                        transaccion.tipo === 'ingreso' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {transaccion.tipo === 'ingreso' ? '+' : ''}{formatCurrency(Math.abs(transaccion.monto))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logros ND */}
          <TabsContent value="logros" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-blue-400" />
                  Sistema de Logros Neurodivergente
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Gamificación adaptada para mantener la motivación
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {logros.map((logro) => (
                    <div key={logro.id} className={`p-6 rounded-lg border ${
                      logro.desbloqueado 
                        ? 'bg-blue-900/20 border-blue-500/20' 
                        : 'bg-gray-900/20 border-gray-500/20'
                    }`}>
                      <div className="flex items-center space-x-3 mb-3">
                        <div className={`text-3xl ${logro.desbloqueado ? '' : 'grayscale opacity-50'}`}>
                          {logro.icono}
                        </div>
                        <div>
                          <h3 className={`text-lg font-semibold ${
                            logro.desbloqueado ? 'text-blue-400' : 'text-gray-500'
                          }`}>
                            {logro.nombre}
                          </h3>
                          <p className="text-sm text-gray-400">{logro.descripcion}</p>
                        </div>
                      </div>
                      {logro.desbloqueado && (
                        <div className="flex items-center space-x-1 text-green-400 text-sm">
                          <CheckCircle className="w-4 h-4" />
                          <span>¡Logro desbloqueado!</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <DollarSign className="w-6 h-6 text-green-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                FINANZAS ND
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              Primera plataforma de gestión financiera neurodivergente del mundo
            </p>
            <p className="text-gray-500 text-xs">
              Finanzas personales adaptadas a tu neurotipo, con gamificación y herramientas especializadas
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
              <span>© 2024 FINANZAS ND</span>
              <span>•</span>
              <span>Desarrollado con 💰 por Manolo</span>
              <span>•</span>
              <span>Para Cata y la comunidad ND</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

