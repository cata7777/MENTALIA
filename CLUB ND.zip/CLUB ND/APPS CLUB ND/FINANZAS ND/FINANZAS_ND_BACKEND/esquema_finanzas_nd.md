
# Esquema Técnico - FINANZAS ND

## Modelos
- TransaccionND(id, usuario_id, tipo, monto, fecha, descripcion, categoria_id)
- CategoriaND(id, nombre, color, icono)
- MetaFinanciera(id, usuario_id, nombre, monto_objetivo, monto_actual, fecha_limite, cumplida)
- AlarmaND(id, usuario_id, tipo, mensaje, fecha_hora, activo)

## Integración ND
- PerfilND ajusta visualización y alertas
- Diagnóstico simplificado, categorías adaptadas por neurotipo

## Mejoras Aplicadas
- Iconos + colores en categorías
- Alarmas suaves, configurables
- Endpoint de integración por perfil
