import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  MessageSquare, 
  Volume2, 
  VolumeX, 
  Type, 
  Image,
  Video,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  Send,
  Smile,
  Heart,
  Brain,
  Users,
  User,
  Settings,
  Palette,
  Accessibility,
  Eye,
  EyeOff,
  Headphones,
  Speaker,
  Pause,
  Play,
  SkipForward,
  SkipBack,
  RotateCcw,
  Save,
  Download,
  Upload,
  Share2,
  Copy,
  Edit,
  Trash2,
  Plus,
  Minus,
  ZoomIn,
  ZoomOut,
  MoreHorizontal,
  Filter,
  Search,
  Star,
  Bookmark,
  Flag,
  AlertCircle,
  CheckCircle,
  Info,
  HelpCircle,
  Lightbulb,
  Target,
  Award,
  Sparkles,
  Zap,
  Shield,
  Lock,
  Unlock,
  Globe,
  Wifi,
  WifiOff,
  Smartphone,
  Tablet,
  Monitor,
  Keyboard,
  Mouse,
  Gamepad2,
  Joystick,
  Puzzle,
  PuzzleIcon,
  Layers,
  Grid3X3,
  Layout,
  LayoutGrid,
  LayoutList,
  Menu,
  X,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Home,
  Back,
  Forward,
  Refresh,
  Clock,
  Calendar,
  Timer,
  Stopwatch,
  Bell,
  BellOff,
  Vibrate,
  VolumeIcon,
  Activity,
  TrendingUp,
  BarChart3,
  PieChart,
  LineChart,
  Thermometer,
  Battery,
  BatteryLow,
  Wifi as WifiIcon,
  Signal,
  SignalHigh,
  SignalLow,
  SignalMedium,
  SignalZero
} from 'lucide-react'
import './App.css'

function App() {
  const [modoActual, setModoActual] = useState('comunicacion')
  const [perfilUsuario, setPerfilUsuario] = useState('TDAH')
  const [configuracionAccesibilidad, setConfiguracionAccesibilidad] = useState({
    tamañoTexto: 'normal',
    contraste: 'normal',
    sonidos: true,
    vibracion: true,
    animaciones: true,
    lecturaVoz: false,
    modoOscuro: false
  })

  // Datos del usuario
  const usuario = {
    nombre: 'Alex Comunicador',
    neurotipo: 'TDAH + Autismo',
    edad: 16,
    preferencias: {
      comunicacion: 'Visual + Auditiva',
      velocidad: 'Lenta',
      complejidad: 'Simple'
    },
    logros: 47,
    sesionesCompletadas: 23,
    progreso: 78
  }

  // Herramientas de comunicación por neurotipo
  const herramientasComunicacion = {
    'TDAH': [
      { id: 1, nombre: 'Comunicación Rápida', icono: Zap, descripcion: 'Mensajes directos y concisos', color: 'bg-orange-100 text-orange-800' },
      { id: 2, nombre: 'Recordatorios Visuales', icono: Eye, descripcion: 'Ayudas visuales para mantener el foco', color: 'bg-blue-100 text-blue-800' },
      { id: 3, nombre: 'Pausas Programadas', icono: Timer, descripcion: 'Descansos automáticos en conversaciones', color: 'bg-green-100 text-green-800' },
      { id: 4, nombre: 'Filtro de Distracciones', icono: Filter, descripcion: 'Reduce elementos que distraen', color: 'bg-purple-100 text-purple-800' }
    ],
    'Autismo': [
      { id: 5, nombre: 'Comunicación Estructurada', icono: Grid3X3, descripcion: 'Patrones predecibles de conversación', color: 'bg-blue-100 text-blue-800' },
      { id: 6, nombre: 'Símbolos y Pictogramas', icono: Image, descripcion: 'Comunicación visual alternativa', color: 'bg-green-100 text-green-800' },
      { id: 7, nombre: 'Tiempo de Procesamiento', icono: Clock, descripcion: 'Pausas para procesar información', color: 'bg-yellow-100 text-yellow-800' },
      { id: 8, nombre: 'Rutinas de Comunicación', icono: RotateCcw, descripcion: 'Secuencias familiares de interacción', color: 'bg-purple-100 text-purple-800' }
    ],
    'Altas Capacidades': [
      { id: 9, nombre: 'Comunicación Compleja', icono: Brain, descripcion: 'Conversaciones de alto nivel', color: 'bg-purple-100 text-purple-800' },
      { id: 10, nombre: 'Múltiples Canales', icono: Layers, descripcion: 'Información en varios formatos', color: 'bg-blue-100 text-blue-800' },
      { id: 11, nombre: 'Análisis Profundo', icono: Target, descripcion: 'Herramientas de análisis detallado', color: 'bg-green-100 text-green-800' },
      { id: 12, nombre: 'Personalización Avanzada', icono: Settings, descripcion: 'Control total de la experiencia', color: 'bg-orange-100 text-orange-800' }
    ]
  }

  // Tablero de comunicación con símbolos
  const tableroSimbolos = [
    { categoria: 'Emociones', simbolos: [
      { id: 'feliz', texto: 'Feliz', icono: '😊', color: 'bg-yellow-200' },
      { id: 'triste', texto: 'Triste', icono: '😢', color: 'bg-blue-200' },
      { id: 'enojado', texto: 'Enojado', icono: '😠', color: 'bg-red-200' },
      { id: 'cansado', texto: 'Cansado', icono: '😴', color: 'bg-purple-200' },
      { id: 'emocionado', texto: 'Emocionado', icono: '🤩', color: 'bg-orange-200' },
      { id: 'confundido', texto: 'Confundido', icono: '😕', color: 'bg-gray-200' }
    ]},
    { categoria: 'Necesidades', simbolos: [
      { id: 'agua', texto: 'Agua', icono: '💧', color: 'bg-blue-200' },
      { id: 'comida', texto: 'Comida', icono: '🍎', color: 'bg-green-200' },
      { id: 'descanso', texto: 'Descanso', icono: '🛏️', color: 'bg-purple-200' },
      { id: 'ayuda', texto: 'Ayuda', icono: '🆘', color: 'bg-red-200' },
      { id: 'silencio', texto: 'Silencio', icono: '🤫', color: 'bg-gray-200' },
      { id: 'espacio', texto: 'Espacio', icono: '🚪', color: 'bg-yellow-200' }
    ]},
    { categoria: 'Actividades', simbolos: [
      { id: 'jugar', texto: 'Jugar', icono: '🎮', color: 'bg-green-200' },
      { id: 'estudiar', texto: 'Estudiar', icono: '📚', color: 'bg-blue-200' },
      { id: 'musica', texto: 'Música', icono: '🎵', color: 'bg-purple-200' },
      { id: 'caminar', texto: 'Caminar', icono: '🚶', color: 'bg-orange-200' },
      { id: 'hablar', texto: 'Hablar', icono: '💬', color: 'bg-yellow-200' },
      { id: 'crear', texto: 'Crear', icono: '🎨', color: 'bg-pink-200' }
    ]}
  ]

  const [mensajeActual, setMensajeActual] = useState('')
  const [conversaciones, setConversaciones] = useState([
    { id: 1, tipo: 'recibido', contenido: '¡Hola! ¿Cómo te sientes hoy?', hora: '10:30' },
    { id: 2, tipo: 'enviado', contenido: '😊 ¡Feliz!', hora: '10:31' },
    { id: 3, tipo: 'recibido', contenido: '¡Qué bueno! ¿Quieres hacer alguna actividad?', hora: '10:32' },
    { id: 4, tipo: 'enviado', contenido: '🎮 Jugar', hora: '10:33' }
  ])

  const agregarSimbolo = (simbolo) => {
    setMensajeActual(prev => prev + simbolo.icono + ' ' + simbolo.texto + ' ')
  }

  const enviarMensaje = () => {
    if (mensajeActual.trim()) {
      const nuevoMensaje = {
        id: conversaciones.length + 1,
        tipo: 'enviado',
        contenido: mensajeActual,
        hora: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
      }
      setConversaciones([...conversaciones, nuevoMensaje])
      setMensajeActual('')
    }
  }

  const estadisticas = {
    mensajesEnviados: 156,
    simbolosUsados: 89,
    conversacionesActivas: 5,
    tiempoPromedio: '3.2 min',
    satisfaccion: 94,
    herramientasFavoritas: 3
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-green-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                  COMUNICACIÓN ND
                </h1>
                <p className="text-sm text-gray-600">Plataforma Neuroafirmativa</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-green-100 text-green-700">
                <Brain className="w-3 h-3 mr-1" />
                {usuario.neurotipo}
              </Badge>
              <Button variant="outline" size="sm">
                <User className="w-4 h-4 mr-2" />
                {usuario.nombre}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <Tabs value={modoActual} onValueChange={setModoActual} className="mb-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="comunicacion">Comunicación</TabsTrigger>
            <TabsTrigger value="herramientas">Herramientas</TabsTrigger>
            <TabsTrigger value="tablero">Tablero</TabsTrigger>
            <TabsTrigger value="estadisticas">Estadísticas</TabsTrigger>
            <TabsTrigger value="configuracion">Configuración</TabsTrigger>
          </TabsList>

          {/* Comunicación Principal */}
          <TabsContent value="comunicacion" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Panel de Conversación */}
              <div className="lg:col-span-2">
                <Card className="h-[600px] flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <MessageSquare className="w-5 h-5 text-green-600" />
                      <span>Conversación Activa</span>
                    </CardTitle>
                    <CardDescription>
                      Comunicación adaptada a tu neurotipo
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    {/* Área de mensajes */}
                    <div className="flex-1 overflow-y-auto space-y-3 mb-4 p-4 bg-gray-50 rounded-lg">
                      {conversaciones.map((mensaje) => (
                        <div
                          key={mensaje.id}
                          className={`flex ${mensaje.tipo === 'enviado' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              mensaje.tipo === 'enviado'
                                ? 'bg-green-500 text-white'
                                : 'bg-white border border-gray-200'
                            }`}
                          >
                            <p className="text-sm">{mensaje.contenido}</p>
                            <p className={`text-xs mt-1 ${
                              mensaje.tipo === 'enviado' ? 'text-green-100' : 'text-gray-500'
                            }`}>
                              {mensaje.hora}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Input de mensaje */}
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={mensajeActual}
                        onChange={(e) => setMensajeActual(e.target.value)}
                        placeholder="Escribe tu mensaje o usa símbolos..."
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && enviarMensaje()}
                      />
                      <Button onClick={enviarMensaje} className="bg-green-500 hover:bg-green-600">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Panel de Herramientas Rápidas */}
              <div className="space-y-6">
                {/* Perfil del Usuario */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <User className="w-5 h-5 text-blue-600" />
                      <span>Perfil ND</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <User className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-lg">{usuario.nombre}</h3>
                      <Badge className="bg-blue-100 text-blue-800 mt-1">
                        <Brain className="w-3 h-3 mr-1" />
                        {usuario.neurotipo}
                      </Badge>
                    </div>
                    
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span>Progreso:</span>
                        <span className="font-semibold">{usuario.progreso}%</span>
                      </div>
                      <Progress value={usuario.progreso} className="w-full" />
                      
                      <div className="flex justify-between">
                        <span>Sesiones:</span>
                        <span className="font-semibold">{usuario.sesionesCompletadas}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>Logros:</span>
                        <span className="font-semibold">{usuario.logros}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Accesos Rápidos */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Zap className="w-5 h-5 text-yellow-600" />
                      <span>Accesos Rápidos</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" size="sm" className="h-16 flex flex-col">
                        <Volume2 className="w-6 h-6 mb-1" />
                        <span className="text-xs">Texto a Voz</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-16 flex flex-col">
                        <Mic className="w-6 h-6 mb-1" />
                        <span className="text-xs">Voz a Texto</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-16 flex flex-col">
                        <Image className="w-6 h-6 mb-1" />
                        <span className="text-xs">Símbolos</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-16 flex flex-col">
                        <Timer className="w-6 h-6 mb-1" />
                        <span className="text-xs">Pausas</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Estadísticas Rápidas */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="w-5 h-5 text-purple-600" />
                      <span>Hoy</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Mensajes:</span>
                        <span className="font-semibold">12</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Símbolos:</span>
                        <span className="font-semibold">8</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tiempo activo:</span>
                        <span className="font-semibold">45 min</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Herramientas por Neurotipo */}
          <TabsContent value="herramientas" className="space-y-6">
            <div className="flex space-x-4 mb-6">
              {Object.keys(herramientasComunicacion).map((neurotipo) => (
                <Button
                  key={neurotipo}
                  variant={perfilUsuario === neurotipo ? "default" : "outline"}
                  onClick={() => setPerfilUsuario(neurotipo)}
                >
                  {neurotipo}
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {herramientasComunicacion[perfilUsuario]?.map((herramienta) => (
                <Card key={herramienta.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                      <herramienta.icono className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{herramienta.nombre}</h3>
                    <p className="text-gray-600 text-sm mb-4">{herramienta.descripcion}</p>
                    <Badge className={herramienta.color}>
                      Disponible
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tablero de Comunicación */}
          <TabsContent value="tablero" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Grid3X3 className="w-5 h-5 text-green-600" />
                  <span>Tablero de Comunicación</span>
                </CardTitle>
                <CardDescription>
                  Símbolos y pictogramas para comunicación alternativa
                </CardDescription>
              </CardHeader>
              <CardContent>
                {tableroSimbolos.map((categoria) => (
                  <div key={categoria.categoria} className="mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">
                      {categoria.categoria}
                    </h3>
                    <div className="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-8 gap-4">
                      {categoria.simbolos.map((simbolo) => (
                        <button
                          key={simbolo.id}
                          onClick={() => agregarSimbolo(simbolo)}
                          className={`${simbolo.color} p-4 rounded-lg hover:scale-105 transition-transform text-center border-2 border-transparent hover:border-gray-300`}
                        >
                          <div className="text-3xl mb-2">{simbolo.icono}</div>
                          <div className="text-xs font-medium">{simbolo.texto}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Estadísticas */}
          <TabsContent value="estadisticas" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100 text-sm">Mensajes</p>
                      <p className="text-2xl font-bold">{estadisticas.mensajesEnviados}</p>
                    </div>
                    <MessageSquare className="w-6 h-6 text-green-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100 text-sm">Símbolos</p>
                      <p className="text-2xl font-bold">{estadisticas.simbolosUsados}</p>
                    </div>
                    <Image className="w-6 h-6 text-blue-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100 text-sm">Conversaciones</p>
                      <p className="text-2xl font-bold">{estadisticas.conversacionesActivas}</p>
                    </div>
                    <Users className="w-6 h-6 text-purple-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100 text-sm">Tiempo Prom.</p>
                      <p className="text-2xl font-bold">{estadisticas.tiempoPromedio}</p>
                    </div>
                    <Clock className="w-6 h-6 text-orange-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-pink-500 to-pink-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-pink-100 text-sm">Satisfacción</p>
                      <p className="text-2xl font-bold">{estadisticas.satisfaccion}%</p>
                    </div>
                    <Star className="w-6 h-6 text-pink-200" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-cyan-100 text-sm">Herramientas</p>
                      <p className="text-2xl font-bold">{estadisticas.herramientasFavoritas}</p>
                    </div>
                    <Zap className="w-6 h-6 text-cyan-200" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Gráficos de Progreso */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Uso de Herramientas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { herramienta: 'Símbolos', uso: 85, color: 'bg-green-500' },
                      { herramienta: 'Texto a Voz', uso: 72, color: 'bg-blue-500' },
                      { herramienta: 'Pausas', uso: 68, color: 'bg-purple-500' },
                      { herramienta: 'Filtros', uso: 45, color: 'bg-orange-500' }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-24 text-sm">{item.herramienta}</div>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`${item.color} h-2 rounded-full`}
                            style={{ width: `${item.uso}%` }}
                          ></div>
                        </div>
                        <div className="w-12 text-sm font-semibold">{item.uso}%</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Progreso Semanal</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((dia, index) => {
                      const progreso = [20, 35, 45, 30, 55, 40, 25][index]
                      return (
                        <div key={dia} className="flex items-center space-x-3">
                          <div className="w-8 text-sm font-medium">{dia}</div>
                          <div className="flex-1 bg-gray-200 rounded-full h-3">
                            <div 
                              className="bg-gradient-to-r from-green-400 to-blue-500 h-3 rounded-full"
                              style={{ width: `${progreso}%` }}
                            ></div>
                          </div>
                          <div className="w-12 text-sm">{progreso} min</div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Configuración */}
          <TabsContent value="configuracion" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-gray-600" />
                  <span>Configuración de Accesibilidad</span>
                </CardTitle>
                <CardDescription>
                  Personaliza la experiencia según tus necesidades neurodivergentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <h3 className="font-semibold text-lg">Configuración Visual</h3>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Tamaño de texto</span>
                        <select 
                          value={configuracionAccesibilidad.tamañoTexto}
                          onChange={(e) => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            tamañoTexto: e.target.value
                          })}
                          className="border border-gray-300 rounded px-3 py-1"
                        >
                          <option value="pequeño">Pequeño</option>
                          <option value="normal">Normal</option>
                          <option value="grande">Grande</option>
                          <option value="extra-grande">Extra Grande</option>
                        </select>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span>Contraste</span>
                        <select 
                          value={configuracionAccesibilidad.contraste}
                          onChange={(e) => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            contraste: e.target.value
                          })}
                          className="border border-gray-300 rounded px-3 py-1"
                        >
                          <option value="normal">Normal</option>
                          <option value="alto">Alto</option>
                          <option value="muy-alto">Muy Alto</option>
                        </select>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span>Modo oscuro</span>
                        <Button
                          variant={configuracionAccesibilidad.modoOscuro ? "default" : "outline"}
                          size="sm"
                          onClick={() => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            modoOscuro: !configuracionAccesibilidad.modoOscuro
                          })}
                        >
                          {configuracionAccesibilidad.modoOscuro ? 'Activado' : 'Desactivado'}
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <h3 className="font-semibold text-lg">Configuración de Interacción</h3>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Sonidos</span>
                        <Button
                          variant={configuracionAccesibilidad.sonidos ? "default" : "outline"}
                          size="sm"
                          onClick={() => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            sonidos: !configuracionAccesibilidad.sonidos
                          })}
                        >
                          {configuracionAccesibilidad.sonidos ? 'Activado' : 'Desactivado'}
                        </Button>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span>Vibración</span>
                        <Button
                          variant={configuracionAccesibilidad.vibracion ? "default" : "outline"}
                          size="sm"
                          onClick={() => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            vibracion: !configuracionAccesibilidad.vibracion
                          })}
                        >
                          {configuracionAccesibilidad.vibracion ? 'Activado' : 'Desactivado'}
                        </Button>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span>Animaciones</span>
                        <Button
                          variant={configuracionAccesibilidad.animaciones ? "default" : "outline"}
                          size="sm"
                          onClick={() => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            animaciones: !configuracionAccesibilidad.animaciones
                          })}
                        >
                          {configuracionAccesibilidad.animaciones ? 'Activado' : 'Desactivado'}
                        </Button>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span>Lectura por voz</span>
                        <Button
                          variant={configuracionAccesibilidad.lecturaVoz ? "default" : "outline"}
                          size="sm"
                          onClick={() => setConfiguracionAccesibilidad({
                            ...configuracionAccesibilidad,
                            lecturaVoz: !configuracionAccesibilidad.lecturaVoz
                          })}
                        >
                          {configuracionAccesibilidad.lecturaVoz ? 'Activado' : 'Desactivado'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <footer className="mt-16 text-center py-8 border-t border-green-200">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <MessageSquare className="w-6 h-6 text-green-600" />
            <span className="text-lg font-semibold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              COMUNICACIÓN ND
            </span>
          </div>
          <p className="text-gray-600 mb-2">
            Plataforma de comunicación neuroafirmativa con herramientas adaptativas
          </p>
          <p className="text-sm text-gray-500">
            Desarrollado con 💙 por Manolo para el ecosistema ND
          </p>
        </footer>
      </div>
    </div>
  )
}

export default App

