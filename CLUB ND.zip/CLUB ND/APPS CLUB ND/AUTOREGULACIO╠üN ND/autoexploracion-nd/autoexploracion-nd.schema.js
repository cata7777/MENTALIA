/**
 * AUTOEXPLORACIÓN ND - Esquema de Base de Datos
 * Plataforma de Tests y Evaluaciones Neurodivergentes Personalizadas
 * 
 * Autor: Catalina Rojo Lema
 * Análisis Técnico: Manus AI (Manolo)
 * Fecha: Diciembre 2024
 */

const mongoose = require('mongoose');

// Esquema para tests de autoexploración
const testAutoexploracionSchema = new mongoose.Schema({
  // Identificación
  test_id: {
    type: String,
    required: true,
    unique: true,
    default: () => `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  },
  
  // Información básica del test
  informacion_basica: {
    nombre_test: {
      type: String,
      required: true
    },
    descripcion_breve: String,
    descripcion_detallada: String,
    version_test: {
      type: String,
      default: '1.0'
    },
    idioma: {
      type: String,
      default: 'es'
    }
  },
  
  // Categorización del test
  categorizacion: {
    tipo_evaluacion: {
      type: String,
      enum: ['screening', 'diagnostico_diferencial', 'perfil_detallado', 'seguimiento', 'autoconocimiento'],
      required: true
    },
    neurodivergencias_objetivo: [String],
    areas_evaluadas: [String],
    grupo_edad: {
      minima: Number,
      maxima: Number,
      descripcion: String
    },
    genero_consideraciones: [String]
  },
  
  // Estructura del test
  estructura_test: {
    numero_secciones: Number,
    numero_preguntas_total: Number,
    tiempo_estimado_minutos: Number,
    tipo_respuestas: [String],
    escalas_utilizadas: [String],
    puntuacion_maxima: Number,
    puntuacion_minima: Number
  },
  
  // Secciones del test
  secciones: [{
    numero_seccion: Number,
    nombre_seccion: String,
    descripcion_seccion: String,
    area_evaluada: String,
    numero_preguntas: Number,
    instrucciones_especificas: String,
    peso_seccion: Number // porcentaje del total
  }],
  
  // Preguntas del test
  preguntas: [{
    numero_pregunta: Number,
    seccion_pertenece: Number,
    texto_pregunta: String,
    tipo_pregunta: {
      type: String,
      enum: ['likert_5', 'likert_7', 'si_no', 'multiple_choice', 'escala_numerica', 'texto_libre', 'seleccion_multiple']
    },
    opciones_respuesta: [String],
    puntuacion_opciones: [Number],
    pregunta_inversa: Boolean,
    obligatoria: Boolean,
    ayuda_contextual: String,
    ejemplos: [String]
  }],
  
  // Criterios de interpretación
  criterios_interpretacion: {
    rangos_puntuacion: [{
      nombre_rango: String,
      puntuacion_minima: Number,
      puntuacion_maxima: Number,
      interpretacion: String,
      recomendaciones: [String],
      nivel_riesgo: {
        type: String,
        enum: ['bajo', 'medio', 'alto', 'muy_alto']
      }
    }],
    
    perfiles_resultado: [{
      nombre_perfil: String,
      criterios_cumplimiento: [String],
      descripcion_perfil: String,
      fortalezas_identificadas: [String],
      areas_atencion: [String],
      recomendaciones_especificas: [String]
    }],
    
    algoritmo_puntuacion: {
      formula_calculo: String,
      pesos_secciones: [Number],
      ajustes_edad: Boolean,
      ajustes_genero: Boolean,
      normalizacion: Boolean
    }
  },
  
  // Validación científica
  validacion_cientifica: {
    estudios_validacion: [String],
    poblacion_normativa: String,
    confiabilidad: {
      alpha_cronbach: Number,
      test_retest: Number,
      consistencia_interna: Number
    },
    validez: {
      validez_contenido: Number,
      validez_criterio: Number,
      validez_constructo: Number
    },
    sensibilidad: Number,
    especificidad: Number
  },
  
  // Adaptaciones neurodivergentes
  adaptaciones_nd: {
    tiempo_extendido: Boolean,
    pausas_permitidas: Boolean,
    formato_accesible: Boolean,
    lectura_asistida: Boolean,
    ejemplos_adicionales: Boolean,
    lenguaje_simplificado: Boolean,
    soporte_visual: Boolean,
    feedback_inmediato: Boolean
  },
  
  // Configuración de administración
  configuracion_administracion: {
    auto_administrado: Boolean,
    requiere_supervisor: Boolean,
    modalidad_aplicacion: [String],
    dispositivos_compatibles: [String],
    requisitos_tecnicos: [String],
    tiempo_sesion_maxima: Number,
    guardado_automatico: Boolean,
    reanudacion_permitida: Boolean
  },
  
  // Métricas del test
  metricas_test: {
    veces_administrado: {
      type: Number,
      default: 0
    },
    tiempo_promedio_completado: Number,
    tasa_completacion: {
      type: Number,
      min: 0,
      max: 100
    },
    satisfaccion_usuarios: {
      type: Number,
      min: 1,
      max: 5
    },
    precision_diagnostica: Number
  },
  
  // Estado del test
  estado_test: {
    tipo: String,
    enum: ['desarrollo', 'piloto', 'activo', 'revision', 'obsoleto'],
    default: 'desarrollo'
  },
  
  fecha_creacion: {
    type: Date,
    default: Date.now
  },
  
  fecha_ultima_revision: Date,
  
  // Autoría y créditos
  autoria: {
    autor_principal: String,
    colaboradores: [String],
    institucion: String,
    referencias_bibliograficas: [String],
    licencia_uso: String
  }
}, {
  timestamps: true,
  collection: 'tests_autoexploracion'
});

// Esquema para respuestas de tests
const respuestaTestSchema = new mongoose.Schema({
  // Identificación
  respuesta_id: {
    type: String,
    required: true,
    unique: true,
    default: () => `resp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  },
  
  // Test y usuario
  test_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'TestAutoexploracion',
    required: true
  },
  
  usuario_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  
  // Información de la sesión
  informacion_sesion: {
    fecha_inicio: {
      type: Date,
      default: Date.now
    },
    fecha_finalizacion: Date,
    tiempo_total_minutos: Number,
    dispositivo_utilizado: String,
    navegador_utilizado: String,
    interrupciones: Number,
    pausas_realizadas: Number,
    completado: Boolean
  },
  
  // Respuestas por pregunta
  respuestas_preguntas: [{
    numero_pregunta: Number,
    respuesta_seleccionada: mongoose.Schema.Types.Mixed,
    puntuacion_obtenida: Number,
    tiempo_respuesta_segundos: Number,
    cambios_respuesta: Number,
    confianza_respuesta: {
      type: Number,
      min: 1,
      max: 5
    },
    comentario_adicional: String
  }],
  
  // Puntuaciones por sección
  puntuaciones_secciones: [{
    numero_seccion: Number,
    nombre_seccion: String,
    puntuacion_bruta: Number,
    puntuacion_normalizada: Number,
    percentil: Number,
    interpretacion_seccion: String
  }],
  
  // Resultado general
  resultado_general: {
    puntuacion_total_bruta: Number,
    puntuacion_total_normalizada: Number,
    percentil_general: Number,
    rango_resultado: String,
    interpretacion_general: String,
    nivel_riesgo: String,
    perfil_identificado: String
  },
  
  // Análisis detallado
  analisis_detallado: {
    fortalezas_identificadas: [String],
    areas_atencion: [String],
    patrones_respuesta: [String],
    inconsistencias_detectadas: [String],
    validez_respuestas: {
      type: String,
      enum: ['valida', 'cuestionable', 'invalida']
    },
    factores_confusores: [String]
  },
  
  // Recomendaciones personalizadas
  recomendaciones: {
    recomendaciones_inmediatas: [String],
    recomendaciones_mediano_plazo: [String],
    recomendaciones_largo_plazo: [String],
    recursos_sugeridos: [String],
    profesionales_recomendados: [String],
    tests_adicionales: [String],
    seguimiento_sugerido: String
  },
  
  // Información contextual
  informacion_contextual: {
    edad_evaluado: Number,
    genero_evaluado: String,
    nivel_educativo: String,
    situacion_actual: String,
    motivo_evaluacion: String,
    expectativas_previas: String,
    experiencias_previas_evaluacion: Boolean
  },
  
  // Feedback del usuario
  feedback_usuario: {
    facilidad_comprension: {
      type: Number,
      min: 1,
      max: 5
    },
    relevancia_preguntas: {
      type: Number,
      min: 1,
      max: 5
    },
    tiempo_adecuado: Boolean,
    utilidad_resultado: {
      type: Number,
      min: 1,
      max: 5
    },
    recomendaria_test: Boolean,
    comentarios_mejora: String,
    satisfaccion_general: {
      type: Number,
      min: 1,
      max: 5
    }
  },
  
  // Seguimiento posterior
  seguimiento_posterior: [{
    fecha_seguimiento: Date,
    tipo_seguimiento: String,
    resultado_seguimiento: String,
    cambios_observados: [String],
    acciones_tomadas: [String],
    efectividad_recomendaciones: {
      type: Number,
      min: 1,
      max: 5
    }
  }],
  
  // Metadatos
  metadatos: {
    version_test_utilizada: String,
    algoritmo_puntuacion: String,
    normas_aplicadas: String,
    ajustes_realizados: [String],
    calidad_datos: {
      type: String,
      enum: ['alta', 'media', 'baja']
    }
  }
}, {
  timestamps: true,
  collection: 'respuestas_tests'
});

// Esquema para perfiles neurodivergentes generados
const perfilGeneradoSchema = new mongoose.Schema({
  // Identificación
  perfil_generado_id: {
    type: String,
    required: true,
    unique: true,
    default: () => `perfil_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  },
  
  // Usuario asociado
  usuario_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  
  // Tests que contribuyeron al perfil
  tests_contribuyentes: [{
    test_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TestAutoexploracion'
    },
    respuesta_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'RespuestaTest'
    },
    peso_contribucion: Number,
    fecha_aplicacion: Date
  }],
  
  // Información del perfil
  informacion_perfil: {
    fecha_generacion: {
      type: Date,
      default: Date.now
    },
    version_algoritmo: String,
    confianza_perfil: {
      type: Number,
      min: 0,
      max: 100
    },
    estado_perfil: {
      type: String,
      enum: ['preliminar', 'consolidado', 'validado', 'actualizado'],
      default: 'preliminar'
    }
  },
  
  // Neurodivergencias identificadas
  neurodivergencias_identificadas: [{
    tipo_neurodivergencia: String,
    probabilidad: {
      type: Number,
      min: 0,
      max: 100
    },
    nivel_evidencia: {
      type: String,
      enum: ['bajo', 'medio', 'alto', 'muy_alto']
    },
    criterios_cumplidos: [String],
    areas_manifestacion: [String],
    intensidad: {
      type: String,
      enum: ['leve', 'moderada', 'severa', 'variable']
    }
  }],
  
  // Perfil cognitivo
  perfil_cognitivo: {
    fortalezas_cognitivas: [{
      area: String,
      nivel: {
        type: String,
        enum: ['promedio', 'superior', 'muy_superior', 'excepcional']
      },
      descripcion: String,
      evidencia: [String]
    }],
    
    desafios_cognitivos: [{
      area: String,
      nivel_dificultad: {
        type: String,
        enum: ['leve', 'moderado', 'severo']
      },
      descripcion: String,
      impacto_funcional: String,
      estrategias_compensatorias: [String]
    }],
    
    estilo_procesamiento: {
      velocidad_procesamiento: String,
      estilo_aprendizaje: [String],
      preferencias_modalidad: [String],
      estrategias_efectivas: [String]
    }
  },
  
  // Perfil sensorial
  perfil_sensorial: {
    sensibilidades: [{
      modalidad_sensorial: String,
      tipo_sensibilidad: {
        type: String,
        enum: ['hiposensibilidad', 'hipersensibilidad', 'busqueda_sensorial', 'evitacion_sensorial']
      },
      intensidad: {
        type: String,
        enum: ['leve', 'moderada', 'severa']
      },
      contextos_manifestacion: [String],
      estrategias_regulacion: [String]
    }],
    
    preferencias_sensoriales: [{
      modalidad: String,
      preferencias: [String],
      aversiones: [String],
      necesidades_especiales: [String]
    }]
  },
  
  // Perfil social y comunicativo
  perfil_social: {
    habilidades_sociales: [{
      area: String,
      nivel_habilidad: {
        type: String,
        enum: ['emergente', 'en_desarrollo', 'consolidada', 'avanzada']
      },
      contextos_exitosos: [String],
      contextos_desafiantes: [String],
      apoyos_necesarios: [String]
    }],
    
    estilo_comunicativo: {
      modalidades_preferidas: [String],
      fortalezas_comunicativas: [String],
      desafios_comunicativos: [String],
      adaptaciones_necesarias: [String]
    },
    
    relaciones_interpersonales: {
      patron_relacional: String,
      preferencias_sociales: [String],
      necesidades_relacionales: [String],
      estrategias_vinculacion: [String]
    }
  },
  
  // Perfil emocional
  perfil_emocional: {
    regulacion_emocional: {
      fortalezas: [String],
      desafios: [String],
      estrategias_efectivas: [String],
      triggers_identificados: [String]
    },
    
    expresion_emocional: {
      modalidades_expresion: [String],
      intensidad_emocional: String,
      alexitimia_presente: Boolean,
      necesidades_apoyo: [String]
    }
  },
  
  // Recomendaciones integradas
  recomendaciones_integradas: {
    estrategias_vida_diaria: [String],
    adaptaciones_educativas: [String],
    adaptaciones_laborales: [String],
    intervenciones_terapeuticas: [String],
    recursos_apoyo: [String],
    seguimiento_recomendado: String
  },
  
  // Evolución del perfil
  evolucion_perfil: [{
    fecha_actualizacion: Date,
    cambios_identificados: [String],
    nuevas_evidencias: [String],
    ajustes_recomendaciones: [String],
    motivo_actualizacion: String
  }],
  
  // Validación externa
  validacion_externa: {
    validado_profesional: Boolean,
    profesional_validador: String,
    fecha_validacion: Date,
    comentarios_profesional: String,
    ajustes_sugeridos: [String],
    nivel_concordancia: {
      type: Number,
      min: 0,
      max: 100
    }
  }
}, {
  timestamps: true,
  collection: 'perfiles_generados'
});

// Esquema para biblioteca de recursos
const recursoAutoexploracionSchema = new mongoose.Schema({
  // Identificación
  recurso_id: {
    type: String,
    required: true,
    unique: true,
    default: () => `recurso_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  },
  
  // Información básica
  informacion_basica: {
    titulo: {
      type: String,
      required: true
    },
    descripcion: String,
    tipo_recurso: {
      type: String,
      enum: ['articulo', 'video', 'podcast', 'libro', 'herramienta', 'ejercicio', 'guia', 'checklist'],
      required: true
    },
    formato: String,
    idioma: String,
    duracion_estimada: String
  },
  
  // Categorización
  categorizacion: {
    neurodivergencias_aplicables: [String],
    areas_tematicas: [String],
    nivel_complejidad: {
      type: String,
      enum: ['basico', 'intermedio', 'avanzado']
    },
    grupo_objetivo: [String],
    contexto_uso: [String]
  },
  
  // Contenido
  contenido: {
    resumen: String,
    objetivos_aprendizaje: [String],
    conceptos_clave: [String],
    actividades_incluidas: [String],
    materiales_necesarios: [String]
  },
  
  // Acceso y disponibilidad
  acceso: {
    url_recurso: String,
    archivo_local: String,
    acceso_gratuito: Boolean,
    requiere_registro: Boolean,
    costo: Number,
    disponibilidad: {
      type: String,
      enum: ['siempre', 'limitada', 'bajo_solicitud']
    }
  },
  
  // Calidad y validación
  calidad: {
    fuente_confiable: Boolean,
    evidencia_cientifica: Boolean,
    actualizado: Boolean,
    fecha_ultima_revision: Date,
    calificacion_usuarios: {
      type: Number,
      min: 1,
      max: 5
    },
    numero_evaluaciones: Number
  },
  
  // Métricas de uso
  metricas_uso: {
    veces_recomendado: {
      type: Number,
      default: 0
    },
    veces_accedido: {
      type: Number,
      default: 0
    },
    tiempo_promedio_uso: Number,
    satisfaccion_promedio: {
      type: Number,
      min: 1,
      max: 5
    },
    efectividad_reportada: {
      type: Number,
      min: 1,
      max: 5
    }
  }
}, {
  timestamps: true,
  collection: 'recursos_autoexploracion'
});

// Índices para optimización
testAutoexploracionSchema.index({ 'categorizacion.neurodivergencias_objetivo': 1 });
testAutoexploracionSchema.index({ 'categorizacion.tipo_evaluacion': 1 });
testAutoexploracionSchema.index({ estado_test: 1 });

respuestaTestSchema.index({ test_id: 1, usuario_id: 1 });
respuestaTestSchema.index({ 'informacion_sesion.fecha_inicio': -1 });
respuestaTestSchema.index({ 'informacion_sesion.completado': 1 });

perfilGeneradoSchema.index({ usuario_id: 1 });
perfilGeneradoSchema.index({ 'informacion_perfil.fecha_generacion': -1 });
perfilGeneradoSchema.index({ 'neurodivergencias_identificadas.tipo_neurodivergencia': 1 });

recursoAutoexploracionSchema.index({ 'categorizacion.neurodivergencias_aplicables': 1 });
recursoAutoexploracionSchema.index({ 'informacion_basica.tipo_recurso': 1 });
recursoAutoexploracionSchema.index({ 'calidad.calificacion_usuarios': -1 });

module.exports = {
  TestAutoexploracion: mongoose.model('TestAutoexploracion', testAutoexploracionSchema),
  RespuestaTest: mongoose.model('RespuestaTest', respuestaTestSchema),
  PerfilGenerado: mongoose.model('PerfilGenerado', perfilGeneradoSchema),
  RecursoAutoexploracion: mongoose.model('RecursoAutoexploracion', recursoAutoexploracionSchema)
};

