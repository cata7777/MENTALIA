
# 🧠 MODELOS - TEST DE AUTORREGULACIÓN ND

class UsuarioAutoReg:
    id: int
    nombre: str
    edad: int
    neurotipo: str

class PreguntaAutoReg:
    id: int
    tipo: str  # emocional, atencional, frustración
    enunciado: str
    opciones: list
    nivel_dificultad: str

class ResultadoAutoReg:
    id: int
    usuario_id: int
    respuestas: list
    puntaje_total: int
    categoria: str
    recomendaciones: list
