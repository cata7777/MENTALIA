
# 🛠️ ENDPOINTS - AUTORREGULACIÓN ND

from flask import Blueprint, request, jsonify

autoreg_bp = Blueprint("autoreg_nd", __name__)
usuarios = []
resultados = []

@autoreg_bp.route("/api/autoreg/usuario", methods=["POST"])
def registrar_usuario_autoreg():
    data = request.get_json()
    usuarios.append(data)
    return jsonify({"id": len(usuarios)}), 201

@autoreg_bp.route("/api/autoreg/test", methods=["POST"])
def guardar_resultado():
    data = request.get_json()
    resultados.append(data)
    return jsonify({"id": len(resultados)}), 201

@autoreg_bp.route("/api/autoreg/resultados/<int:usuario_id>", methods=["GET"])
def ver_resultados(usuario_id):
    res = [r for r in resultados if r["usuario_id"] == usuario_id]
    return jsonify(res), 200
