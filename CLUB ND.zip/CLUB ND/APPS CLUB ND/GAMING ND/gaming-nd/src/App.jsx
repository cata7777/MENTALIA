import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Gamepad2, 
  Trophy, 
  Star, 
  Zap, 
  Brain, 
  Target, 
  Heart, 
  Play, 
  Pause, 
  RotateCcw,
  Settings,
  Users,
  Award,
  TrendingUp,
  Calendar,
  Clock,
  CheckCircle,
  Circle,
  Lock,
  Unlock,
  Volume2,
  VolumeX,
  Home,
  Compass,
  BookOpen,
  User,
  Plus,
  Minus,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  Flame,
  Snowflake,
  Wind,
  Waves,
  Mountain,
  TreePine,
  Sun,
  Moon,
  Eye,
  EyeOff,
  Headphones,
  Music,
  Mic,
  Camera,
  Image,
  Video,
  Download,
  Upload,
  Share2,
  Bookmark,
  Flag,
  MoreHorizontal,
  Edit,
  Trash2,
  Save,
  RefreshCw,
  Maximize,
  Minimize,
  X,
  Check,
  AlertCircle,
  Info,
  HelpCircle,
  Search,
  Filter,
  SortAsc,
  SortDesc,
  Grid,
  List,
  Map,
  BarChart3,
  PieChart,
  Activity,
  Cpu,
  Wifi,
  WifiOff,
  Battery,
  BatteryLow,
  Signal,
  Bluetooth,
  Smartphone,
  Tablet,
  Monitor,
  Laptop,
  Keyboard,
  Mouse,
  Joystick,
  Gamepad,
  Controller,
  Dice1,
  Dice2,
  Dice3,
  Dice4,
  Dice5,
  Dice6,
  Puzzle,
  Lightbulb,
  Rocket,
  Shield,
  Sword,
  Wand2,
  Crown,
  Gem,
  Coins,
  Gift,
  Medal,
  Ribbon
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedNeurotipo, setSelectedNeurotipo] = useState('tdah')
  const [currentGame, setCurrentGame] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [gameTime, setGameTime] = useState(0)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [difficulty, setDifficulty] = useState('medio')
  const [gameProgress, setGameProgress] = useState(0)

  // Datos del jugador
  const playerData = {
    nombre: 'Catalina Boetsch',
    username: 'cata_gamer_nd',
    neurotipo: 'TDAH + Altas Capacidades',
    avatar: '🦋',
    nivel: 47,
    experiencia: 15420,
    experienciaProximoNivel: 18000,
    puntosTotal: 89567,
    logrosDesbloqueados: 23,
    logrosTotal: 50,
    juegosFavoritos: 8,
    tiempoJugado: '156h 23m',
    rachaActual: 12,
    insignias: ['🧠', '⚡', '🎯', '🏆', '🌟', '🔥', '💎'],
    estadisticas: {
      concentracion: 94,
      memoria: 87,
      velocidadProcesamiento: 91,
      flexibilidadCognitiva: 89,
      controlInhibitorio: 76,
      planificacion: 83
    }
  }

  // Juegos por neurotipo
  const juegosPorNeurotipo = {
    tdah: [
      {
        id: 1,
        titulo: 'Hiperfoco Quest',
        descripcion: 'Aventura épica que entrena la concentración sostenida',
        categoria: 'Aventura Cognitiva',
        dificultad: 'Adaptativa',
        duracion: '15-45 min',
        jugadores: 'Individual',
        beneficios: ['Concentración', 'Atención sostenida', 'Control de impulsos'],
        rating: 4.9,
        jugados: 15420,
        completado: 78,
        icono: '🎯',
        color: 'from-red-500 to-orange-500',
        tipo: 'terapeutico',
        nivelRequerido: 1,
        desbloqueado: true,
        ultimaPartida: 'hace 2 horas',
        mejorPuntuacion: 8945,
        tiempoRecord: '23:45'
      },
      {
        id: 2,
        titulo: 'Dopamine Rush',
        descripcion: 'Juego de recompensas que optimiza la motivación',
        categoria: 'Puzzle Dinámico',
        dificultad: 'Progresiva',
        duracion: '10-30 min',
        jugadores: '1-4',
        beneficios: ['Motivación', 'Recompensa diferida', 'Planificación'],
        rating: 4.8,
        jugados: 12890,
        completado: 65,
        icono: '⚡',
        color: 'from-yellow-500 to-red-500',
        tipo: 'terapeutico',
        nivelRequerido: 5,
        desbloqueado: true,
        ultimaPartida: 'hace 1 día',
        mejorPuntuacion: 12340,
        tiempoRecord: '18:32'
      },
      {
        id: 3,
        titulo: 'Time Master',
        descripcion: 'Gestión del tiempo gamificada para TDAH',
        categoria: 'Simulación',
        dificultad: 'Personalizable',
        duracion: '20-60 min',
        jugadores: 'Individual',
        beneficios: ['Gestión temporal', 'Organización', 'Productividad'],
        rating: 4.7,
        jugados: 9876,
        completado: 45,
        icono: '⏰',
        color: 'from-blue-500 to-purple-500',
        tipo: 'educativo',
        nivelRequerido: 10,
        desbloqueado: true,
        ultimaPartida: 'hace 3 días',
        mejorPuntuacion: 7890,
        tiempoRecord: '35:12'
      }
    ],
    autismo: [
      {
        id: 4,
        titulo: 'Sensory Garden',
        descripcion: 'Exploración sensorial relajante y terapéutica',
        categoria: 'Exploración Sensorial',
        dificultad: 'Suave',
        duracion: '10-∞ min',
        jugadores: 'Individual',
        beneficios: ['Regulación sensorial', 'Calma', 'Autoconocimiento'],
        rating: 4.9,
        jugados: 18765,
        completado: 89,
        icono: '🌸',
        color: 'from-green-500 to-teal-500',
        tipo: 'terapeutico',
        nivelRequerido: 1,
        desbloqueado: true,
        ultimaPartida: 'hace 4 horas',
        mejorPuntuacion: 9999,
        tiempoRecord: '∞'
      },
      {
        id: 5,
        titulo: 'Pattern Universe',
        descripcion: 'Descubre y crea patrones en un universo infinito',
        categoria: 'Puzzle Creativo',
        dificultad: 'Escalable',
        duracion: '15-90 min',
        jugadores: '1-2',
        beneficios: ['Reconocimiento de patrones', 'Creatividad', 'Lógica'],
        rating: 4.8,
        jugados: 14532,
        completado: 72,
        icono: '🔮',
        color: 'from-purple-500 to-pink-500',
        tipo: 'educativo',
        nivelRequerido: 3,
        desbloqueado: true,
        ultimaPartida: 'hace 1 día',
        mejorPuntuacion: 15678,
        tiempoRecord: '42:18'
      },
      {
        id: 6,
        titulo: 'Social Scripts',
        descripcion: 'Practica habilidades sociales en escenarios seguros',
        categoria: 'Simulación Social',
        dificultad: 'Adaptativa',
        duracion: '20-45 min',
        jugadores: '1-6',
        beneficios: ['Habilidades sociales', 'Comunicación', 'Empatía'],
        rating: 4.6,
        jugados: 8901,
        completado: 34,
        icono: '👥',
        color: 'from-blue-500 to-cyan-500',
        tipo: 'social',
        nivelRequerido: 8,
        desbloqueado: true,
        ultimaPartida: 'hace 2 días',
        mejorPuntuacion: 6789,
        tiempoRecord: '28:45'
      }
    ],
    altasCapacidades: [
      {
        id: 7,
        titulo: 'Quantum Minds',
        descripcion: 'Desafíos cognitivos de alta complejidad',
        categoria: 'Estrategia Avanzada',
        dificultad: 'Extrema',
        duracion: '30-120 min',
        jugadores: '1-8',
        beneficios: ['Pensamiento crítico', 'Resolución compleja', 'Creatividad'],
        rating: 4.9,
        jugados: 5432,
        completado: 23,
        icono: '🧠',
        color: 'from-indigo-500 to-purple-500',
        tipo: 'desafio',
        nivelRequerido: 15,
        desbloqueado: true,
        ultimaPartida: 'hace 6 horas',
        mejorPuntuacion: 23456,
        tiempoRecord: '67:23'
      },
      {
        id: 8,
        titulo: 'Innovation Lab',
        descripcion: 'Laboratorio virtual para crear e inventar',
        categoria: 'Creatividad Libre',
        dificultad: 'Sin límites',
        duracion: '45-∞ min',
        jugadores: '1-12',
        beneficios: ['Innovación', 'Creatividad', 'Pensamiento divergente'],
        rating: 4.8,
        jugados: 7890,
        completado: 56,
        icono: '🚀',
        color: 'from-yellow-500 to-orange-500',
        tipo: 'creativo',
        nivelRequerido: 20,
        desbloqueado: true,
        ultimaPartida: 'hace 5 horas',
        mejorPuntuacion: 34567,
        tiempoRecord: '∞'
      },
      {
        id: 9,
        titulo: 'Meta Puzzle',
        descripcion: 'Puzzles que se transforman mientras los resuelves',
        categoria: 'Puzzle Metamórfico',
        dificultad: 'Dinámica',
        duracion: '25-75 min',
        jugadores: 'Individual',
        beneficios: ['Flexibilidad cognitiva', 'Adaptabilidad', 'Metacognición'],
        rating: 4.7,
        jugados: 6543,
        completado: 41,
        icono: '🧩',
        color: 'from-pink-500 to-purple-500',
        tipo: 'puzzle',
        nivelRequerido: 12,
        desbloqueado: true,
        ultimaPartida: 'hace 1 día',
        mejorPuntuacion: 18901,
        tiempoRecord: '51:34'
      }
    ]
  }

  // Logros disponibles
  const logrosDisponibles = [
    { id: 1, nombre: 'Primer Juego', descripcion: 'Completa tu primer juego', icono: '🎮', desbloqueado: true, rareza: 'común' },
    { id: 2, nombre: 'Concentración Zen', descripcion: 'Juega 30 minutos sin pausa', icono: '🧘‍♀️', desbloqueado: true, rareza: 'común' },
    { id: 3, nombre: 'Racha de Fuego', descripcion: '7 días consecutivos jugando', icono: '🔥', desbloqueado: true, rareza: 'raro' },
    { id: 4, nombre: 'Maestro del Hiperfoco', descripcion: 'Completa Hiperfoco Quest 10 veces', icono: '🎯', desbloqueado: true, rareza: 'épico' },
    { id: 5, nombre: 'Explorador Sensorial', descripción: 'Descubre todos los jardines sensoriales', icono: '🌸', desbloqueado: true, rareza: 'raro' },
    { id: 6, nombre: 'Genio Cuántico', descripcion: 'Resuelve el nivel más difícil de Quantum Minds', icono: '🧠', desbloqueado: false, rareza: 'legendario' },
    { id: 7, nombre: 'Innovador del Año', descripcion: 'Crea 50 inventos en Innovation Lab', icono: '🚀', desbloqueado: false, rareza: 'mítico' },
    { id: 8, nombre: 'Conexión Social', descripcion: 'Completa 20 escenarios sociales', icono: '👥', desbloqueado: true, rareza: 'épico' }
  ]

  // Torneos activos
  const torneosActivos = [
    {
      id: 1,
      nombre: 'Copa Hiperfoco 2024',
      juego: 'Hiperfoco Quest',
      participantes: 1247,
      premio: '10,000 puntos + Insignia Dorada',
      fechaFin: '2024-07-30',
      posicionActual: 23,
      tipo: 'individual'
    },
    {
      id: 2,
      nombre: 'Desafío Sensorial',
      juego: 'Sensory Garden',
      participantes: 892,
      premio: '5,000 puntos + Jardín Exclusivo',
      fechaFin: '2024-07-25',
      posicionActual: 8,
      tipo: 'relajado'
    },
    {
      id: 3,
      nombre: 'Liga de Genios',
      juego: 'Quantum Minds',
      participantes: 456,
      premio: '25,000 puntos + Título Legendario',
      fechaFin: '2024-08-15',
      posicionActual: 12,
      tipo: 'competitivo'
    }
  ]

  // Estadísticas de la comunidad
  const estadisticasComunidad = {
    jugadoresActivos: 47892,
    partidasHoy: 15420,
    horasJugadas: 892567,
    logrosDesbloqueados: 234567,
    torneosActivos: 12,
    juegoMasPopular: 'Hiperfoco Quest'
  }

  // Simulación de tiempo de juego
  useEffect(() => {
    let interval = null
    if (isPlaying && currentGame) {
      interval = setInterval(() => {
        setGameTime(time => time + 1)
        setGameProgress(progress => Math.min(100, progress + 0.5))
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, currentGame])

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatNumber = (num) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M'
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k'
    }
    return num.toString()
  }

  const getRarezaColor = (rareza) => {
    switch (rareza) {
      case 'común': return 'text-gray-400'
      case 'raro': return 'text-blue-400'
      case 'épico': return 'text-purple-400'
      case 'legendario': return 'text-orange-400'
      case 'mítico': return 'text-pink-400'
      default: return 'text-gray-400'
    }
  }

  const handlePlayGame = (juego) => {
    setCurrentGame(juego)
    setIsPlaying(true)
    setGameTime(0)
    setGameProgress(0)
  }

  const handlePauseGame = () => {
    setIsPlaying(false)
  }

  const handleStopGame = () => {
    setIsPlaying(false)
    setCurrentGame(null)
    setGameTime(0)
    setGameProgress(0)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Gamepad2 className="w-8 h-8 text-violet-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-fuchsia-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
                  GAMING ND
                </h1>
                <p className="text-xs text-gray-300">Videojuegos Terapéuticos Neurodivergentes</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-violet-400 text-violet-400">
                <Trophy className="w-3 h-3 mr-1" />
                Nivel {playerData.nivel}
              </Badge>
              <div className="text-right">
                <p className="text-sm font-medium text-white">{playerData.nombre}</p>
                <p className="text-xs text-gray-400">{playerData.username}</p>
              </div>
              <div className="w-8 h-8 bg-violet-500/20 rounded-full flex items-center justify-center text-lg">
                {playerData.avatar}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-black/20 backdrop-blur-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-violet-500/20">
              <Home className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="juegos" className="data-[state=active]:bg-purple-500/20">
              <Gamepad2 className="w-4 h-4 mr-2" />
              Juegos
            </TabsTrigger>
            <TabsTrigger value="progreso" className="data-[state=active]:bg-fuchsia-500/20">
              <TrendingUp className="w-4 h-4 mr-2" />
              Progreso
            </TabsTrigger>
            <TabsTrigger value="logros" className="data-[state=active]:bg-pink-500/20">
              <Award className="w-4 h-4 mr-2" />
              Logros
            </TabsTrigger>
            <TabsTrigger value="torneos" className="data-[state=active]:bg-orange-500/20">
              <Trophy className="w-4 h-4 mr-2" />
              Torneos
            </TabsTrigger>
            <TabsTrigger value="comunidad" className="data-[state=active]:bg-cyan-500/20">
              <Users className="w-4 h-4 mr-2" />
              Comunidad
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Perfil del Jugador */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2 text-violet-400" />
                    Perfil Gamer ND
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-violet-500/20 rounded-full flex items-center justify-center text-3xl mx-auto mb-3">
                      {playerData.avatar}
                    </div>
                    <h3 className="font-semibold text-lg">{playerData.nombre}</h3>
                    <Badge className="mt-2 bg-violet-500/20 text-violet-400">{playerData.neurotipo}</Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-400">Nivel</span>
                      <span className="text-violet-400 font-bold">{playerData.nivel}</span>
                    </div>
                    <Progress value={(playerData.experiencia / playerData.experienciaProximoNivel) * 100} className="h-2" />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{formatNumber(playerData.experiencia)} XP</span>
                      <span>{formatNumber(playerData.experienciaProximoNivel)} XP</span>
                    </div>
                  </div>
                  <div className="flex justify-center space-x-1">
                    {playerData.insignias.map((insignia, index) => (
                      <span key={index} className="text-lg">{insignia}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Estadísticas de Juego */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-purple-400" />
                    Estadísticas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-purple-400">{formatNumber(playerData.puntosTotal)}</p>
                      <p className="text-xs text-gray-400">Puntos Total</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-fuchsia-400">{playerData.rachaActual}</p>
                      <p className="text-xs text-gray-400">Racha (días)</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Tiempo jugado</span>
                      <span className="text-pink-400">{playerData.tiempoJugado}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Juegos favoritos</span>
                      <span className="text-cyan-400">{playerData.juegosFavoritos}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Logros</span>
                      <span className="text-orange-400">{playerData.logrosDesbloqueados}/{playerData.logrosTotal}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Juego Actual */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Gamepad2 className="w-5 h-5 mr-2 text-fuchsia-400" />
                    Sesión Actual
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {currentGame ? (
                    <>
                      <div className="text-center">
                        <div className="text-4xl mb-2">{currentGame.icono}</div>
                        <h3 className="font-semibold">{currentGame.titulo}</h3>
                        <p className="text-sm text-gray-400">{currentGame.categoria}</p>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Tiempo</span>
                          <span className="text-fuchsia-400">{formatTime(gameTime)}</span>
                        </div>
                        <Progress value={gameProgress} className="h-2" />
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Progreso</span>
                          <span>{Math.round(gameProgress)}%</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          onClick={isPlaying ? handlePauseGame : () => setIsPlaying(true)}
                          className="flex-1 bg-fuchsia-500/20 text-fuchsia-400 hover:bg-fuchsia-500/30"
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </Button>
                        <Button
                          size="sm"
                          onClick={handleStopGame}
                          className="bg-red-500/20 text-red-400 hover:bg-red-500/30"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <Gamepad2 className="w-12 h-12 text-gray-500 mx-auto mb-3" />
                      <p className="text-gray-400">No hay juego activo</p>
                      <Button 
                        size="sm" 
                        className="mt-3 bg-violet-500/20 text-violet-400 hover:bg-violet-500/30"
                        onClick={() => setActiveTab('juegos')}
                      >
                        Explorar Juegos
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Juegos Recomendados */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Sparkles className="w-5 h-5 mr-2 text-yellow-400" />
                  Recomendados para Ti
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Basado en tu perfil {playerData.neurotipo} y progreso actual
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[...juegosPorNeurotipo.tdah.slice(0, 2), ...juegosPorNeurotipo.altasCapacidades.slice(0, 1)].map((juego) => (
                    <div key={juego.id} className={`bg-gradient-to-br ${juego.color}/20 p-4 rounded-lg border border-violet-500/20`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-2xl">{juego.icono}</div>
                        <Badge className="bg-violet-500/20 text-violet-400">{juego.categoria}</Badge>
                      </div>
                      <h3 className="font-medium mb-2">{juego.titulo}</h3>
                      <p className="text-xs text-gray-400 mb-3">{juego.descripcion}</p>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-xs text-gray-400">{juego.duracion}</span>
                        <div className="flex items-center text-yellow-400">
                          <Star className="w-3 h-3 mr-1" />
                          <span className="text-xs">{juego.rating}</span>
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full bg-violet-500/20 text-violet-400 hover:bg-violet-500/30"
                        onClick={() => handlePlayGame(juego)}
                      >
                        <Play className="w-3 h-3 mr-1" />
                        Jugar
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Estadísticas Cognitivas */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-cyan-400" />
                  Desarrollo Cognitivo
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Tu progreso en habilidades cognitivas clave
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Object.entries(playerData.estadisticas).map(([habilidad, valor]) => (
                    <div key={habilidad} className="text-center">
                      <div className="relative w-16 h-16 mx-auto mb-2">
                        <svg className="w-16 h-16 transform -rotate-90">
                          <circle
                            cx="32"
                            cy="32"
                            r="28"
                            stroke="currentColor"
                            strokeWidth="4"
                            fill="transparent"
                            className="text-gray-700"
                          />
                          <circle
                            cx="32"
                            cy="32"
                            r="28"
                            stroke="currentColor"
                            strokeWidth="4"
                            fill="transparent"
                            strokeDasharray={`${2 * Math.PI * 28}`}
                            strokeDashoffset={`${2 * Math.PI * 28 * (1 - valor / 100)}`}
                            className="text-cyan-400"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-sm font-bold text-cyan-400">{valor}</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 capitalize">{habilidad.replace(/([A-Z])/g, ' $1').trim()}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Juegos */}
          <TabsContent value="juegos" className="space-y-6 mt-6">
            {/* Selector de Neurotipo */}
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Juegos por Neurotipo
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Selecciona tu neurotipo para juegos especializados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4 mb-6">
                  <Button
                    variant={selectedNeurotipo === 'tdah' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('tdah')}
                    className={selectedNeurotipo === 'tdah' ? 'bg-red-500/20 text-red-400' : 'border-red-500/50 text-red-400'}
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    TDAH
                  </Button>
                  <Button
                    variant={selectedNeurotipo === 'autismo' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('autismo')}
                    className={selectedNeurotipo === 'autismo' ? 'bg-green-500/20 text-green-400' : 'border-green-500/50 text-green-400'}
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Autismo
                  </Button>
                  <Button
                    variant={selectedNeurotipo === 'altasCapacidades' ? 'default' : 'outline'}
                    onClick={() => setSelectedNeurotipo('altasCapacidades')}
                    className={selectedNeurotipo === 'altasCapacidades' ? 'bg-yellow-500/20 text-yellow-400' : 'border-yellow-500/50 text-yellow-400'}
                  >
                    <Star className="w-4 h-4 mr-2" />
                    Altas Capacidades
                  </Button>
                </div>

                {/* Lista de Juegos */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {juegosPorNeurotipo[selectedNeurotipo].map((juego) => (
                    <div key={juego.id} className={`bg-gradient-to-br ${juego.color}/20 p-6 rounded-lg border border-violet-500/20`}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-3xl">{juego.icono}</div>
                          <div>
                            <h3 className="text-lg font-semibold">{juego.titulo}</h3>
                            <p className="text-sm text-gray-400">{juego.descripcion}</p>
                          </div>
                        </div>
                        <div className="flex items-center text-yellow-400">
                          <Star className="w-4 h-4 mr-1" />
                          <span className="text-sm">{juego.rating}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <Badge className="bg-violet-500/20 text-violet-400">{juego.categoria}</Badge>
                          <Badge variant="outline" className="border-gray-500 text-gray-400">{juego.dificultad}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-400">Duración:</span>
                            <p className="text-white">{juego.duracion}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Jugadores:</span>
                            <p className="text-white">{juego.jugadores}</p>
                          </div>
                        </div>

                        <div>
                          <span className="text-gray-400 text-sm">Beneficios:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {juego.beneficios.map((beneficio, index) => (
                              <Badge key={index} className="bg-cyan-500/20 text-cyan-400 text-xs">
                                {beneficio}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex justify-between text-sm text-gray-400">
                          <span>{formatNumber(juego.jugados)} jugadas</span>
                          <span>{juego.completado}% completado</span>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-500">
                            <p>Última: {juego.ultimaPartida}</p>
                            <p>Récord: {juego.tiempoRecord}</p>
                          </div>
                          <Button 
                            size="sm" 
                            className="bg-violet-500/20 text-violet-400 hover:bg-violet-500/30"
                            onClick={() => handlePlayGame(juego)}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Jugar
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Progreso */}
          <TabsContent value="progreso" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Progreso General */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                    Progreso General
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-green-400">{playerData.nivel}</p>
                    <p className="text-sm text-gray-400">Nivel Actual</p>
                  </div>
                  <div className="space-y-3">
                    {[
                      { metrica: 'Experiencia Total', valor: formatNumber(playerData.experiencia), cambio: '+1,234', color: 'text-blue-400' },
                      { metrica: 'Puntos Acumulados', valor: formatNumber(playerData.puntosTotal), cambio: '+5,678', color: 'text-purple-400' },
                      { metrica: 'Tiempo de Juego', valor: playerData.tiempoJugado, cambio: '+2h 15m', color: 'text-pink-400' },
                      { metrica: 'Racha Actual', valor: `${playerData.rachaActual} días`, cambio: '+1', color: 'text-orange-400' }
                    ].map((stat, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-900/20 rounded-lg">
                        <span className="text-sm text-gray-300">{stat.metrica}</span>
                        <div className="text-right">
                          <p className={`font-semibold ${stat.color}`}>{stat.valor}</p>
                          <p className="text-xs text-green-400">{stat.cambio}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Habilidades Cognitivas */}
              <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="w-5 h-5 mr-2 text-cyan-400" />
                    Habilidades Cognitivas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(playerData.estadisticas).map(([habilidad, valor]) => (
                    <div key={habilidad} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-300 capitalize">
                          {habilidad.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <span className="text-cyan-400 font-semibold">{valor}%</span>
                      </div>
                      <Progress value={valor} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Logros */}
          <TabsContent value="logros" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-orange-400" />
                  Logros Desbloqueados
                </CardTitle>
                <CardDescription className="text-gray-400">
                  {playerData.logrosDesbloqueados} de {playerData.logrosTotal} logros completados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {logrosDisponibles.map((logro) => (
                    <div key={logro.id} className={`p-4 rounded-lg border ${
                      logro.desbloqueado 
                        ? 'bg-orange-900/20 border-orange-500/20' 
                        : 'bg-gray-900/20 border-gray-500/20'
                    }`}>
                      <div className="flex items-center space-x-3 mb-3">
                        <div className={`text-3xl ${logro.desbloqueado ? '' : 'grayscale opacity-50'}`}>
                          {logro.icono}
                        </div>
                        <div className="flex-1">
                          <h4 className={`font-medium ${logro.desbloqueado ? 'text-orange-400' : 'text-gray-500'}`}>
                            {logro.nombre}
                          </h4>
                          <p className={`text-xs ${logro.desbloqueado ? 'text-gray-300' : 'text-gray-500'}`}>
                            {logro.descripcion}
                          </p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <Badge className={`text-xs ${getRarezaColor(logro.rareza)}`}>
                          {logro.rareza}
                        </Badge>
                        {logro.desbloqueado && (
                          <CheckCircle className="w-5 h-5 text-orange-400" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Torneos */}
          <TabsContent value="torneos" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-yellow-400" />
                  Torneos Activos
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Compite con otros jugadores neurodivergentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {torneosActivos.map((torneo) => (
                    <div key={torneo.id} className="bg-yellow-900/20 p-6 rounded-lg border border-yellow-500/20">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-yellow-400">{torneo.nombre}</h3>
                          <p className="text-sm text-gray-400">Juego: {torneo.juego}</p>
                        </div>
                        <Badge className={`${
                          torneo.tipo === 'competitivo' ? 'bg-red-500/20 text-red-400' :
                          torneo.tipo === 'relajado' ? 'bg-green-500/20 text-green-400' :
                          'bg-blue-500/20 text-blue-400'
                        }`}>
                          {torneo.tipo}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <span className="text-xs text-gray-400">Participantes</span>
                          <p className="text-white font-semibold">{formatNumber(torneo.participantes)}</p>
                        </div>
                        <div>
                          <span className="text-xs text-gray-400">Tu Posición</span>
                          <p className="text-yellow-400 font-semibold">#{torneo.posicionActual}</p>
                        </div>
                        <div>
                          <span className="text-xs text-gray-400">Termina</span>
                          <p className="text-white font-semibold">{torneo.fechaFin}</p>
                        </div>
                        <div>
                          <span className="text-xs text-gray-400">Premio</span>
                          <p className="text-green-400 font-semibold text-xs">{torneo.premio}</p>
                        </div>
                      </div>
                      
                      <Button className="w-full bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30">
                        <Trophy className="w-4 h-4 mr-2" />
                        Participar
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Comunidad */}
          <TabsContent value="comunidad" className="space-y-6 mt-6">
            <Card className="bg-black/20 backdrop-blur-md border-white/10 text-white">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-cyan-400" />
                  Comunidad Gaming ND
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Estadísticas y actividad de la comunidad
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mb-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-cyan-400">{formatNumber(estadisticasComunidad.jugadoresActivos)}</p>
                    <p className="text-sm text-gray-400">Jugadores Activos</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-purple-400">{formatNumber(estadisticasComunidad.partidasHoy)}</p>
                    <p className="text-sm text-gray-400">Partidas Hoy</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-pink-400">{formatNumber(estadisticasComunidad.horasJugadas)}</p>
                    <p className="text-sm text-gray-400">Horas Jugadas</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-cyan-900/20 p-4 rounded-lg border border-cyan-500/20">
                    <h4 className="font-semibold text-cyan-400 mb-2">Juego Más Popular</h4>
                    <p className="text-white">{estadisticasComunidad.juegoMasPopular}</p>
                    <p className="text-sm text-gray-400">Jugado por {formatNumber(15420)} personas hoy</p>
                  </div>
                  
                  <div className="bg-purple-900/20 p-4 rounded-lg border border-purple-500/20">
                    <h4 className="font-semibold text-purple-400 mb-2">Torneos Activos</h4>
                    <p className="text-white">{estadisticasComunidad.torneosActivos} torneos en curso</p>
                    <p className="text-sm text-gray-400">¡Únete y compite!</p>
                  </div>
                  
                  <div className="bg-pink-900/20 p-4 rounded-lg border border-pink-500/20">
                    <h4 className="font-semibold text-pink-400 mb-2">Logros Desbloqueados</h4>
                    <p className="text-white">{formatNumber(estadisticasComunidad.logrosDesbloqueados)} logros</p>
                    <p className="text-sm text-gray-400">¡La comunidad está en racha!</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <Gamepad2 className="w-6 h-6 text-violet-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
                GAMING ND
              </span>
            </div>
            <p className="text-gray-400 text-sm">
              Primera plataforma de videojuegos terapéuticos neurodivergentes
            </p>
            <p className="text-gray-500 text-xs">
              Transformando el gaming en terapia, potenciando cada neurotipo
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
              <span>© 2024 GAMING ND</span>
              <span>•</span>
              <span>Desarrollado con 🎮 por Manolo</span>
              <span>•</span>
              <span>Para Cata y la comunidad ND</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

