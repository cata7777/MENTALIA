# 🧠 ECOSISTEMA MENTALIA
## Red de Sistemas Inteligentes Interconectados para el Desarrollo Humano Integral

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com/mentalia/ecosystem)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D20.0.0-brightgreen.svg)](https://nodejs.org/)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](https://docker.com/)
[![RunPod](https://img.shields.io/badge/runpod-optimized-purple.svg)](https://runpod.io/)

### 🌟 Descripción

MENTALIA es un ecosistema revolucionario de **60+ aplicaciones especializadas** de inteligencia artificial diseñadas para potenciar el desarrollo humano integral. Utilizando la metodología propietaria de "Mentalización Dimensional", el ecosistema abarca cinco áreas fundamentales: Educación, Salud, Gerencia, Justicia y Herramientas Transversales.

### 🏗️ Arquitectura del Ecosistema

```
MENTALIA ECOSYSTEM
├── 🎓 EDUCACIÓN IA (15 sistemas)
│   ├── Plataforma Principal: Educación IA
│   ├── Equipo Docente: Profesor IA, Tutor IA, Evaluador IA, Mentor IA
│   ├── Herramientas: Generador de Exámenes, Corrector IA, Planificador Curricular
│   └── Plataformas: EduCode, Academia Virtual, Biblioteca Digital
│
├── 🏥 SALUD IA (12 sistemas)
│   ├── Plataforma Principal: Salud IA
│   ├── Equipo Médico: Doctor IA, Psicólogo IA, Nutricionista IA, Entrenador Personal IA
│   ├── Herramientas: Monitor de Salud, Planificador de Dietas, Tracker de Ejercicios
│   └── Plataformas: MedCode, Telemedicina IA, Laboratorio Virtual
│
├── 💼 GERENCIA IA (10 sistemas)
│   ├── Plataforma Principal: Gerencia IA
│   ├── Equipo Gerencial: Gerente General, Finanzas, Marketing, Operaciones
│   ├── Herramientas: Auditor Interno, Analista de Datos, BoletaApp, Sistema de Proyecciones
│   └── Plataformas: CRM Inteligente, Monitor de KPIs
│
├── ⚖️ JUSTICIA IA (8 sistemas)
│   ├── Plataforma Principal: Justicia IA
│   ├── Equipo Legal: Abogado IA, Asistente Legal IA, Mediador IA
│   └── Plataformas: LexCode, Firma Legal IA, Notario Virtual, Tribunal Virtual
│
└── 🛠️ HERRAMIENTAS TRANSVERSALES (15 sistemas)
    ├── Creación: Botmaker Universal, Check Assistant, Asistente de CI
    ├── Infraestructura: Soldado Lógico, Hiperfoco, RSII
    ├── Comercio: Tienda Mentalia, Comunidad Mentalia
    ├── Productividad: Agenda Universal, Traductor Universal, Asistente de Escritura
    └── Análisis: Analizador de Sentimientos, Predictor de Tendencias, Optimizador de Recursos
```

### 🚀 Inicio Rápido

#### Prerrequisitos
- Node.js >= 20.0.0
- Docker & Docker Compose
- PostgreSQL 15+
- Redis 7+

#### Instalación Local

```bash
# Clonar el repositorio
git clone https://github.com/mentalia/ecosystem.git
cd mentalia-ecosystem

# Instalar dependencias
npm run setup

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus configuraciones

# Inicializar base de datos
npm run migrate
npm run seed

# Iniciar en modo desarrollo
npm run dev
```

#### Despliegue con Docker

```bash
# Construir imágenes
npm run docker:build

# Iniciar servicios
npm run docker:up

# Ver logs
npm run docker:logs
```

#### Despliegue en RunPod

```bash
# Usar script de instalación automática
curl -sSL https://raw.githubusercontent.com/mentalia/ecosystem/main/scripts/install-runpod.sh | bash

# O seguir la guía manual
./scripts/setup-runpod.sh [DOMAIN] [EMAIL] [OPENAI_API_KEY]
```

### 📁 Estructura del Proyecto

```
mentalia-ecosystem/
├── 🎨 frontend/                 # Aplicación React principal
│   ├── src/
│   │   ├── components/          # Componentes reutilizables
│   │   ├── pages/              # Páginas de la aplicación
│   │   ├── hooks/              # Custom hooks
│   │   └── lib/                # Utilidades y configuración
│   └── public/                 # Archivos estáticos
│
├── 🔧 services/                # Microservicios especializados
│   ├── educacion/              # Servicios de Educación IA
│   ├── salud/                  # Servicios de Salud IA
│   ├── gerencia/               # Servicios de Gerencia IA
│   ├── justicia/               # Servicios de Justicia IA
│   ├── herramientas/           # Herramientas Transversales
│   ├── auth/                   # Servicio de autenticación
│   ├── gateway/                # API Gateway
│   └── database/               # Gestión de base de datos
│
├── 📦 shared/                  # Código compartido
│   ├── ui/                     # Componentes UI compartidos
│   ├── utils/                  # Utilidades compartidas
│   ├── types/                  # Tipos TypeScript
│   └── config/                 # Configuraciones compartidas
│
├── 🏗️ infrastructure/          # Infraestructura como código
│   ├── docker/                 # Configuraciones Docker
│   ├── kubernetes/             # Manifiestos K8s
│   ├── terraform/              # Infraestructura Terraform
│   └── monitoring/             # Configuración de monitoreo
│
├── 📚 docs/                    # Documentación
│   ├── api/                    # Documentación de APIs
│   ├── user/                   # Manuales de usuario
│   └── developer/              # Guías para desarrolladores
│
├── 🧪 tests/                   # Tests automatizados
│   ├── unit/                   # Tests unitarios
│   ├── integration/            # Tests de integración
│   ├── e2e/                    # Tests end-to-end
│   └── performance/            # Tests de rendimiento
│
└── 🚀 deployment/              # Configuraciones de despliegue
    ├── staging/                # Entorno de staging
    └── production/             # Entorno de producción
```

### 🛠️ Stack Tecnológico

#### Frontend
- **React 19.1.0** - Framework principal
- **Vite 6.3.5** - Build tool y dev server
- **Tailwind CSS 4.1.7** - Framework de estilos
- **Radix UI** - Componentes accesibles
- **Framer Motion** - Animaciones
- **React Router DOM** - Enrutamiento
- **Zustand** - Gestión de estado
- **React Query** - Gestión de datos

#### Backend
- **Node.js 20+** - Runtime
- **Express/Fastify** - Framework web
- **TypeScript** - Tipado estático
- **PostgreSQL 15+** - Base de datos principal
- **Redis 7+** - Cache y sesiones
- **Prisma** - ORM
- **JWT** - Autenticación
- **Socket.io** - WebSockets

#### IA y ML
- **OpenAI GPT-4** - Modelo principal de IA
- **Anthropic Claude** - Modelo alternativo
- **TensorFlow.js** - ML en el frontend
- **LangChain** - Orquestación de LLMs
- **Pinecone** - Base de datos vectorial

#### Infraestructura
- **Docker** - Contenedorización
- **Kubernetes** - Orquestación
- **Kong** - API Gateway
- **Prometheus** - Métricas
- **Grafana** - Dashboards
- **ELK Stack** - Logs
- **RunPod** - Plataforma de despliegue

### 🔧 Comandos Disponibles

#### Desarrollo
```bash
npm run dev                     # Iniciar todo en desarrollo
npm run dev:frontend           # Solo frontend
npm run dev:services           # Solo servicios
npm run dev:educacion          # Solo servicio de educación
```

#### Build y Testing
```bash
npm run build                  # Construir todo
npm run test                   # Ejecutar todos los tests
npm run lint                   # Linting de código
npm run security-scan          # Escaneo de seguridad
```

#### Docker
```bash
npm run docker:build          # Construir imágenes
npm run docker:up             # Iniciar contenedores
npm run docker:down           # Detener contenedores
npm run docker:logs           # Ver logs
```

#### Base de Datos
```bash
npm run migrate               # Ejecutar migraciones
npm run seed                  # Poblar con datos de prueba
npm run backup                # Crear backup
```

#### Despliegue
```bash
npm run deploy:staging        # Desplegar a staging
npm run deploy:production     # Desplegar a producción
npm run health-check          # Verificar salud del sistema
```

### 🌐 URLs de Acceso

#### Desarrollo Local
- **Frontend**: http://localhost:3000
- **API Gateway**: http://localhost:8000
- **Grafana**: http://localhost:3001
- **Prometheus**: http://localhost:9090

#### Producción (RunPod)
- **Frontend**: https://mentalia.runpod.io
- **API**: https://mentalia.runpod.io/api
- **Monitoreo**: https://mentalia.runpod.io/monitoring

### 📊 Métricas y Monitoreo

El ecosistema incluye monitoreo completo con:

- **Performance**: Tiempo de respuesta < 500ms
- **Disponibilidad**: Uptime > 99.9%
- **Escalabilidad**: Soporte para 10,000+ usuarios concurrentes
- **Seguridad**: Cumplimiento GDPR, HIPAA
- **Calidad**: Cobertura de tests > 90%

### 🔐 Seguridad

- **Autenticación**: JWT + OAuth 2.0
- **Autorización**: RBAC (Role-Based Access Control)
- **Encriptación**: TLS 1.3, AES-256
- **Compliance**: GDPR, HIPAA, SOC 2
- **Auditoría**: Logs completos de todas las acciones

### 🤝 Contribución

1. Fork el repositorio
2. Crear rama feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

### 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver [LICENSE](LICENSE) para más detalles.

### 🆘 Soporte

- **Documentación**: [docs.mentalia.ai](https://docs.mentalia.ai)
- **Issues**: [GitHub Issues](https://github.com/mentalia/ecosystem/issues)
- **Discord**: [Comunidad MENTALIA](https://discord.gg/mentalia)
- **Email**: support@mentalia.ai

### 🎯 Roadmap

- **Q1 2025**: Lanzamiento de Educación IA y Salud IA
- **Q2 2025**: Integración completa de Gerencia IA
- **Q3 2025**: Expansión de Justicia IA
- **Q4 2025**: Optimización y escalabilidad global

---

**MENTALIA** - Transformando el futuro del desarrollo humano a través de la inteligencia artificial especializada.

*"Donde la tecnología encuentra la humanidad"* 🚀

