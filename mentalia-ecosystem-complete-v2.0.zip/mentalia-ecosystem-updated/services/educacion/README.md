# 🎓 Servicio de Educación IA - MENTALIA

## Descripción
Microservicio especializado en aplicaciones de inteligencia artificial para educación, parte del ecosistema MENTALIA.

## Aplicaciones Incluidas

### 🏫 Plataforma Principal: Educación IA
- Dashboard personalizado con métricas de aprendizaje
- Sistema de recomendaciones basado en IA
- Analytics avanzado de progreso estudiantil
- Gamificación y sistema de logros

### 👨‍🏫 Equipo Docente Especializado
1. **Profesor IA** - Docente virtual especializado
2. **Tutor IA** - Acompañamiento personalizado
3. **Evaluador IA** - Sistema de evaluación inteligente
4. **Mentor IA** - Orientación vocacional y profesional

### 🛠️ Herramientas Educativas
5. **Generador de Exámenes IA** - Creación automática de evaluaciones
6. **Corrector IA** - Evaluación automática avanzada
7. **Planificador Curricular IA** - Diseño de programas educativos
8. **Simulador de Laboratorio IA** - Experimentos virtuales
9. **Traductor Educativo IA** - Traducción especializada
10. **Asistente de Investigación IA** - Apoyo a la investigación académica

### 🌐 Plataformas Especializadas
11. **EduCode** - Plataforma de programación educativa
12. **Academia Virtual IA** - Campus virtual completo
13. **Biblioteca Digital IA** - Repositorio inteligente
14. **Simulador de Exámenes IA** - Preparación para evaluaciones
15. **Plataforma de Certificaciones IA** - Gestión de credenciales

## 🚀 Inicio Rápido

### Prerrequisitos
- Node.js >= 20.0.0
- PostgreSQL 15+
- Redis 7+
- OpenAI API Key

### Instalación

```bash
# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus configuraciones

# Configurar base de datos
npm run migrate
npm run seed

# Iniciar en desarrollo
npm run dev
```

### Rutas de la API

#### Backend Principal
- **Ruta**: `/services/educacion/src`
- **Puerto**: 3001
- **Comando**: `npm run dev`

#### Estructura de Carpetas
```
src/
├── controllers/     # Controladores de las rutas
├── models/         # Modelos de datos (Prisma)
├── routes/         # Definición de rutas
├── middleware/     # Middlewares personalizados
├── utils/          # Utilidades y helpers
├── config/         # Configuraciones
└── types/          # Tipos TypeScript
```

#### Archivos de Configuración
- `package.json` - Dependencias y scripts
- `prisma/schema.prisma` - Esquema de base de datos
- `tsconfig.json` - Configuración TypeScript
- `.env` - Variables de entorno

## 📡 Endpoints Principales

### Plataforma Educación IA
```
GET    /api/educacion/dashboard          # Dashboard principal
GET    /api/educacion/recommendations    # Recomendaciones personalizadas
GET    /api/educacion/analytics         # Analytics de progreso
POST   /api/educacion/goals             # Crear objetivos de aprendizaje
```

### Profesor IA
```
POST   /api/educacion/profesor/chat     # Chat con Profesor IA
POST   /api/educacion/profesor/lesson   # Generar plan de clase
POST   /api/educacion/profesor/evaluate # Evaluar tarea
GET    /api/educacion/profesor/feedback # Obtener feedback
```

### EduCode
```
POST   /api/educacion/educode/execute   # Ejecutar código
GET    /api/educacion/educode/exercises # Obtener ejercicios
POST   /api/educacion/educode/submit    # Enviar solución
GET    /api/educacion/educode/hints     # Obtener pistas
```

### Evaluador IA
```
POST   /api/educacion/evaluador/create  # Crear examen
POST   /api/educacion/evaluador/grade   # Calificar respuestas
GET    /api/educacion/evaluador/results # Obtener resultados
POST   /api/educacion/evaluador/analyze # Analizar rendimiento
```

## 🗄️ Base de Datos

### Tablas Principales
- `users` - Usuarios del sistema
- `courses` - Cursos disponibles
- `lessons` - Lecciones de los cursos
- `assessments` - Evaluaciones
- `progress` - Progreso de estudiantes
- `ai_interactions` - Interacciones con IA
- `code_submissions` - Envíos de código
- `certificates` - Certificaciones

### Migraciones
```bash
# Crear nueva migración
npx prisma migrate dev --name nombre_migracion

# Aplicar migraciones en producción
npm run migrate:prod

# Ver base de datos
npm run studio
```

## 🧪 Testing

```bash
# Ejecutar tests
npm run test

# Tests con cobertura
npm run test:coverage

# Linting
npm run lint
```

## 🐳 Docker

```bash
# Construir imagen
docker build -t mentalia/educacion-service .

# Ejecutar contenedor
docker run -p 3001:3001 mentalia/educacion-service
```

## 📊 Monitoreo

### Métricas Disponibles
- Tiempo de respuesta de APIs
- Uso de recursos de IA
- Progreso de estudiantes
- Errores y excepciones

### Logs
Los logs se almacenan en:
- Desarrollo: `logs/development.log`
- Producción: Elasticsearch + Kibana

## 🔐 Seguridad

- Autenticación JWT
- Validación de entrada con Zod
- Rate limiting
- Encriptación de datos sensibles
- Auditoría de acciones

## 🚀 Despliegue

### Staging
```bash
npm run build
docker-compose -f docker-compose.staging.yml up -d
```

### Producción
```bash
npm run build
docker-compose -f docker-compose.production.yml up -d
```

## 📚 Documentación

- **API Docs**: http://localhost:3001/api-docs
- **Swagger**: Documentación interactiva de la API
- **Postman**: Colección disponible en `/docs/postman`

## 🤝 Contribución

1. Fork el repositorio
2. Crear rama feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

## 📄 Licencia

MIT License - Ver archivo LICENSE para más detalles.

---

**Servicio de Educación IA** - Transformando la educación a través de la inteligencia artificial 🚀

