// Next.js entry for Agenda Clínica Interoperable
