// IA suggestive diagnosis logic (CIE10 + DSM5 + GES)
