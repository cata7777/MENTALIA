// Digital consent + signature system
