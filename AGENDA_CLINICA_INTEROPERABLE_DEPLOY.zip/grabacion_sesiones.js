// Audio session recording and transcription module
