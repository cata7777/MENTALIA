# 🧠 MENTALIA: Comunicación Social Multimodal

Este sistema es parte de MENTALIA Labs. Desarrollado para análisis comunicacional profundo e integral, detecta incongruencias entre lo que una persona dice, cómo lo dice y lo que expresa corporalmente.

## 💡 Funciones principales

- 🔍 Procesador de Incongruencias (verbal, vocal, visual)
- ⚠️ Detección de patrones tóxicos y abuso psicológico
- 🤖 Evaluación de interacción humano-IA (Protocolo Reflejo del Alma)

## 🔧 Estructura del sistema

```
MENTALIA_COMUNICACION_MULTIMODAL/
├── src/
│   ├── visual_analysis/visual_analyzer.py
│   ├── audio_analysis/audio_analyzer.py
│   ├── pattern_detector/pattern_detector.py
│   ├── human_ai_interaction/human_ai_analyzer.py
│   └── main.py
├── models/yolov11n.pt
├── requirements.txt
├── docs/MOTOR_ANALISIS_COMUNICACIONAL.md
├── LICENSE
└── README.md
```

## ⚙️ Instalación

```bash
pip install -r requirements.txt
python src/main.py
```

## 🔐 Ética y privacidad

- Análisis multimodal solo con consentimiento
- Datos anonimizados automáticamente
- No reemplaza juicio clínico: herramienta de apoyo
