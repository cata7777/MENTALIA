#!/bin/bash
# ============================================================================
# SCRIPT DE INSTALACIÓN AUTOMÁTICA PARA RUNPOD - ECOSISTEMA MENTALIA
# ============================================================================

set -e

echo "🚀 Iniciando instalación del Ecosistema MENTALIA en RunPod..."

# Variables de configuración
DOMAIN=${1:-"mentalia.runpod.io"}
EMAIL=${2:-"admin@mentalia.ai"}
OPENAI_API_KEY=${3:-""}

if [ -z "$OPENAI_API_KEY" ]; then
    echo "❌ Error: OPENAI_API_KEY es requerido"
    echo "Uso: ./install-runpod.sh [DOMAIN] [EMAIL] [OPENAI_API_KEY]"
    exit 1
fi

echo "📋 Configuración:"
echo "   Dominio: $DOMAIN"
echo "   Email: $EMAIL"
echo "   OpenAI API Key: ${OPENAI_API_KEY:0:10}..."
echo

# Actualizar sistema
echo "📦 Actualizando sistema..."
apt-get update && apt-get upgrade -y

# Instalar dependencias básicas
echo "🔧 Instalando dependencias..."
apt-get install -y \
    curl \
    wget \
    git \
    unzip \
    nginx \
    certbot \
    python3-certbot-nginx \
    htop \
    tree \
    jq \
    build-essential

# Instalar Docker
echo "🐳 Instalando Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    systemctl start docker
    systemctl enable docker
    usermod -aG docker $USER
else
    echo "Docker ya está instalado"
fi

# Instalar Docker Compose
echo "🔗 Instalando Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
else
    echo "Docker Compose ya está instalado"
fi

# Instalar Node.js
echo "📦 Instalando Node.js..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo "Node.js ya está instalado"
fi

# Crear directorio del proyecto
echo "📁 Configurando estructura de proyecto..."
mkdir -p /opt/mentalia
cd /opt/mentalia

# Descargar código fuente (simular descarga del ZIP actualizado)
echo "📥 Descargando código fuente del ecosistema..."
# En producción, esto sería:
# wget https://github.com/mentalia/ecosystem/archive/main.zip
# unzip main.zip
# mv ecosystem-main/* .

# Por ahora, crear estructura básica
echo "Creando estructura del ecosistema..."

# Generar contraseñas seguras
POSTGRES_PASSWORD=$(openssl rand -base64 32)
REDIS_PASSWORD=$(openssl rand -base64 32)
KONG_DB_PASSWORD=$(openssl rand -base64 32)
JWT_SECRET=$(openssl rand -base64 64)
GRAFANA_PASSWORD=$(openssl rand -base64 16)

# Configurar variables de entorno
echo "⚙️ Configurando variables de entorno..."
cat > .env << EOF
# Configuración de producción
NODE_ENV=production
ENVIRONMENT=production

# Dominio y SSL
PUBLIC_DOMAIN=${DOMAIN}
ADMIN_EMAIL=${EMAIL}

# Base de datos
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
POSTGRES_USER=mentalia
POSTGRES_DB=mentalia_main

# Redis
REDIS_PASSWORD=${REDIS_PASSWORD}

# API Gateway
KONG_DB_PASSWORD=${KONG_DB_PASSWORD}

# Autenticación
JWT_SECRET=${JWT_SECRET}
SESSION_SECRET=$(openssl rand -base64 32)

# APIs de IA
OPENAI_API_KEY=${OPENAI_API_KEY}

# Monitoreo
GRAFANA_PASSWORD=${GRAFANA_PASSWORD}

# RunPod específico
RUNPOD_POD_ID=${RUNPOD_POD_ID:-""}
RUNPOD_PUBLIC_IP=${RUNPOD_PUBLIC_IP:-""}

# Puertos
FRONTEND_PORT=3000
GATEWAY_PORT=8000
EDUCACION_PORT=3001
SALUD_PORT=3002
GERENCIA_PORT=3003
JUSTICIA_PORT=3004
HERRAMIENTAS_PORT=3005

# Configuración de servicios
EDUCACION_AI_MODEL=gpt-4
SALUD_AI_MODEL=gpt-4
GERENCIA_AI_MODEL=gpt-4
JUSTICIA_AI_MODEL=gpt-4

# Seguridad
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
CORS_ORIGIN=*

# Logs y monitoreo
LOG_LEVEL=info
SENTRY_DSN=${SENTRY_DSN:-""}
EOF

# Configurar Nginx
echo "🌐 Configurando Nginx..."
cat > /etc/nginx/sites-available/mentalia << EOF
server {
    listen 80;
    server_name ${DOMAIN};
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${DOMAIN};

    # SSL Configuration (se configurará con certbot)
    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Frontend principal
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    # API Gateway
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # WebSocket support
    location /ws/ {
        proxy_pass http://localhost:8000/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Monitoreo (protegido)
    location /monitoring/ {
        auth_basic "Área Restringida";
        auth_basic_user_file /etc/nginx/.htpasswd;
        proxy_pass http://localhost:3001/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Habilitar sitio
ln -sf /etc/nginx/sites-available/mentalia /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Configurar SSL si no es IP
echo "🔒 Configurando SSL..."
if [[ ! $DOMAIN =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    certbot --nginx -d ${DOMAIN} --non-interactive --agree-tos --email ${EMAIL} || echo "⚠️ SSL automático falló, configurar manualmente"
else
    echo "⚠️ Usando IP, SSL manual requerido"
fi

# Crear usuario para monitoreo
echo "👤 Configurando autenticación para monitoreo..."
MONITOR_PASSWORD=$(openssl rand -base64 12)
htpasswd -cb /etc/nginx/.htpasswd admin $MONITOR_PASSWORD

# Instalar dependencias del proyecto
echo "📦 Instalando dependencias del proyecto..."
if [ -f "package.json" ]; then
    npm install
fi

# Construir e iniciar servicios con Docker
echo "🏗️ Construyendo e iniciando servicios..."
if [ -f "docker-compose.yml" ]; then
    docker-compose build
    docker-compose up -d
else
    echo "⚠️ docker-compose.yml no encontrado, creando configuración básica..."
    # Aquí se podría crear una configuración básica de Docker Compose
fi

# Configurar scripts de mantenimiento
echo "🔧 Configurando scripts de mantenimiento..."

# Script de health check
cat > /opt/mentalia/health-check.sh << 'EOF'
#!/bin/bash
echo "=== MENTALIA ECOSYSTEM HEALTH CHECK ==="
echo "Timestamp: $(date)"
echo

# Verificar servicios Docker
if command -v docker-compose &> /dev/null; then
    echo "🐳 Docker Services:"
    docker-compose ps
else
    echo "🐳 Docker Services: docker-compose no disponible"
fi

echo
echo "📊 System Resources:"
echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')%"
echo "Memory: $(free -m | awk 'NR==2{printf "%.1f%%", $3*100/$2 }')%"
echo "Disk: $(df -h / | awk 'NR==2 {print $5}')"

echo
echo "🌐 Service Health:"
curl -s -o /dev/null -w "Frontend: %{http_code}\n" http://localhost:3000/health || echo "Frontend: DOWN"
curl -s -o /dev/null -w "API Gateway: %{http_code}\n" http://localhost:8000/health || echo "API Gateway: DOWN"

echo "=== END HEALTH CHECK ==="
EOF

chmod +x /opt/mentalia/health-check.sh

# Script de backup
cat > /opt/mentalia/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/mentalia/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

echo "🗄️ Backing up database..."
if command -v docker-compose &> /dev/null; then
    docker-compose exec -T postgres-main pg_dumpall -U mentalia > $BACKUP_DIR/db_backup_$DATE.sql 2>/dev/null || echo "Database backup failed"
fi

echo "📁 Backing up configuration..."
tar -czf $BACKUP_DIR/config_backup_$DATE.tar.gz .env docker-compose.yml 2>/dev/null || echo "Config backup failed"

echo "🧹 Cleaning old backups..."
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete 2>/dev/null
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete 2>/dev/null

echo "✅ Backup completed: $DATE"
EOF

chmod +x /opt/mentalia/backup.sh

# Configurar cron jobs
echo "⏰ Configurando tareas programadas..."
(crontab -l 2>/dev/null; echo "*/5 * * * * /opt/mentalia/health-check.sh >> /var/log/mentalia-health.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/mentalia/backup.sh >> /var/log/mentalia-backup.log 2>&1") | crontab -

# Configurar logrotate
cat > /etc/logrotate.d/mentalia << EOF
/var/log/mentalia-*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 root root
}
EOF

# Reiniciar Nginx
systemctl restart nginx

# Mostrar información final
echo
echo "✅ ¡Instalación del Ecosistema MENTALIA completada!"
echo
echo "🌐 URLs de acceso:"
echo "   Frontend: https://${DOMAIN}"
echo "   API: https://${DOMAIN}/api"
echo "   Monitoreo: https://${DOMAIN}/monitoring"
echo
echo "🔑 Credenciales generadas:"
echo "   Base de datos: mentalia / ${POSTGRES_PASSWORD}"
echo "   Redis: ${REDIS_PASSWORD}"
echo "   Monitoreo: admin / ${MONITOR_PASSWORD}"
echo "   Grafana: admin / ${GRAFANA_PASSWORD}"
echo
echo "📋 Comandos útiles:"
echo "   Health check: /opt/mentalia/health-check.sh"
echo "   Backup: /opt/mentalia/backup.sh"
echo "   Logs: docker-compose logs -f"
echo "   Restart: docker-compose restart"
echo
echo "📁 Archivos importantes:"
echo "   Configuración: /opt/mentalia/.env"
echo "   Logs: /var/log/mentalia-*.log"
echo "   Backups: /opt/mentalia/backups/"
echo
echo "🚀 El Ecosistema MENTALIA está listo para usar!"
echo "   Visita https://${DOMAIN} para comenzar"
echo

