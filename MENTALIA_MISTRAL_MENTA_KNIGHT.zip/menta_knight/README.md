# 🛡️ MENTA KNIGHT – IA Local con Núcleo Mistral

Una instancia autónoma basada en Mistral, sin conexión directa a GPT. Diseñada para ser el núcleo operativo offline del ecosistema Mentalia.