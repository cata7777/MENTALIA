# Menta_Core

# Núcleo de ejecución autónoma MENTA.