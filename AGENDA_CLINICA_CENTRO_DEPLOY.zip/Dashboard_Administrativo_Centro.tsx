// Ingresos, salas, agendas y control financiero
