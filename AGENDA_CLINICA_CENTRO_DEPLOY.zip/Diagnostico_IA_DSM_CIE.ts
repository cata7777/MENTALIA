// Motor de diagnóstico DSM5 + CIE10 con IA
