// Activación automática de patología GES
