// Emisión de boleta automática por sesión completada
