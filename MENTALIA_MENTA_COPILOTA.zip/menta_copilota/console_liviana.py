# Console Liviana

# Lógica funcional de la copilota.