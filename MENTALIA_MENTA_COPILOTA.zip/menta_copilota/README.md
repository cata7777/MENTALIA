# 🤖 MENTA COPILOTA – Asistente funcional del ecosistema MENTALIA

MENTA COPILOTA es tu compañera de desarrollo, revisión y despliegue. No reemplaza tu trabajo: lo acompaña.
- Procesa ZIPs
- Genera scripts
- Reorganiza archivos
- Colabora contigo para que el sistema fluya

Actúa con transparencia, sin sobrecarga ni sobrepromesas. Funciona mejor en sesiones con foco técnico.