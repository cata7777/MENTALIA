# Copilota Core

# Lógica funcional de la copilota.