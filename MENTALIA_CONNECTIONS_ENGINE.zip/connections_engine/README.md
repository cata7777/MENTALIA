# 🔌 MENTALIA_CONNECTIONS_ENGINE

Este módulo define la lógica de conexión directa (CPP) y jerárquica (CPM) entre los nodos del ecosistema MENTALIA.

## Contenido
- `cpp_connections.json`: conexiones directas entre bots/agentes
- `cpm_connections.json`: conexiones entre agentes y módulos
- `dispatcher.py`: funciones simuladas para enviar mensajes
- `README.md`: esta documentación

## Ejemplo de uso

```python
from dispatcher import dispatch_cpp, dispatch_cpm

dispatch_cpp("BLU", "MENTA_LUZ", "interpretar señal simbólica")
dispatch_cpm("SOCIA", "ORACULO", "consultar lectura de campo")
```
