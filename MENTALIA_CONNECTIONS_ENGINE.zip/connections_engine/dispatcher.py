
# Dispatcher lógico para MENTALIA_CONNECTIONS_ENGINE

def dispatch_cpp(sender, receiver, message):
    print(f"[CPP] {sender} -> {receiver}: {message}")
    return f"Mensaje enviado de {sender} a {receiver}"

def dispatch_cpm(agent, module, action):
    print(f"[CPM] {agent} llama al módulo {module} con acción: {action}")
    return f"{agent} ejecuta acción '{action}' en {module}"
