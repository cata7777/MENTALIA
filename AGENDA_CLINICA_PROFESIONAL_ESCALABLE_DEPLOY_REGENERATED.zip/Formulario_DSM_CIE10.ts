// Formulario inteligente con detección automatizada
