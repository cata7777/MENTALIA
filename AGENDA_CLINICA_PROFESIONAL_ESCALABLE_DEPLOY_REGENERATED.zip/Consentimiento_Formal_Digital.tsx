// Firmas digitales de consentimiento clínico
