#!/usr/bin/env python3
"""
MENTALIA INSTITUCIONAL - Despliegue Empresarial Neurodivergente
Plataforma institucional para organizaciones y empresas
Ecosistema MENTALIA
"""

from flask import Flask, request, jsonify
from datetime import datetime
import json
import uuid

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mentalia_institucional_2025'

class MentaliaInstitucional:
    def __init__(self):
        self.organizaciones_activas = []
        self.usuarios_empresariales = []
        self.stats = {
            'organizaciones_activas': 156,
            'usuarios_empresariales': 47890,
            'roi_promedio': 2.85,
            'satisfaccion_organizacional': 4.8,
            'mejora_productividad': 0.32,
            'reduccion_rotacion': 0.48
        }
        self.inicializar_datos()
    
    def inicializar_datos(self):
        organizaciones_demo = [
            {
                'id': str(uuid.uuid4()),
                'nombre': 'TechCorp Innovación',
                'tipo': 'startup_tecnologica',
                'empleados': 85,
                'plan': 'business',
                'modulos_activos': ['perfil_nd', 'blu_supervisora', 'match_nd', 'journaling_nd'],
                'metricas': {
                    'productividad_mejora': 0.35,
                    'satisfaccion_empleados': 4.7,
                    'rotacion_reduccion': 0.60,
                    'roi_anual': 3.2
                }
            },
            {
                'id': str(uuid.uuid4()),
                'nombre': 'Global Consulting Group',
                'tipo': 'consultoria_multinacional',
                'empleados': 2400,
                'plan': 'enterprise',
                'modulos_activos': ['ecosistema_completo'],
                'metricas': {
                    'productividad_mejora': 0.28,
                    'satisfaccion_empleados': 4.6,
                    'rotacion_reduccion': 0.45,
                    'roi_anual': 2.8
                }
            }
        ]
        self.organizaciones_activas = organizaciones_demo
    
    def crear_organizacion(self, datos_org):
        organizacion = {
            'id': str(uuid.uuid4()),
            'nombre': datos_org.get('nombre'),
            'tipo': datos_org.get('tipo'),
            'empleados': datos_org.get('empleados', 0),
            'plan': self.recomendar_plan(datos_org.get('empleados', 0)),
            'configuracion': self.generar_configuracion_inicial(datos_org),
            'modulos_recomendados': self.recomendar_modulos(datos_org),
            'fecha_creacion': datetime.now().isoformat(),
            'estado': 'configuracion_inicial'
        }
        return organizacion
    
    def recomendar_plan(self, empleados):
        if empleados <= 50:
            return 'startup'
        elif empleados <= 500:
            return 'business'
        elif empleados <= 5000:
            return 'enterprise'
        else:
            return 'global'
    
    def generar_configuracion_inicial(self, datos_org):
        configuracion = {
            'dominio_corporativo': datos_org.get('dominio', 'empresa.com'),
            'sso_habilitado': datos_org.get('empleados', 0) > 100,
            'compliance_requerido': self.determinar_compliance(datos_org.get('industria')),
            'integraciones_necesarias': self.identificar_integraciones(datos_org),
            'personalizacion_marca': True,
            'reportes_ejecutivos': datos_org.get('empleados', 0) > 200
        }
        return configuracion
    
    def recomendar_modulos(self, datos_org):
        modulos_base = ['perfil_nd', 'blu_supervisora']
        empleados = datos_org.get('empleados', 0)
        industria = datos_org.get('industria', 'general')
        
        if empleados > 50:
            modulos_base.extend(['match_nd', 'agenda_clinica'])
        
        if empleados > 200:
            modulos_base.extend(['journaling_nd', 'gerencia_ia'])
        
        if industria == 'tecnologia':
            modulos_base.extend(['club_nd', 'autoexplorador_nd'])
        
        if industria == 'consultoria':
            modulos_base.extend(['cv_nd', 'fl_nd'])
        
        return modulos_base
    
    def determinar_compliance(self, industria):
        compliance_por_industria = {
            'salud': ['hipaa', 'gdpr', 'ley_datos_salud'],
            'financiero': ['sox', 'pci_dss', 'gdpr'],
            'tecnologia': ['gdpr', 'ccpa', 'iso27001'],
            'educacion': ['ferpa', 'gdpr', 'coppa']
        }
        return compliance_por_industria.get(industria, ['gdpr', 'datos_personales'])
    
    def identificar_integraciones(self, datos_org):
        integraciones = ['active_directory', 'google_workspace']
        
        if datos_org.get('empleados', 0) > 100:
            integraciones.extend(['workday', 'successfactors'])
        
        if datos_org.get('industria') == 'tecnologia':
            integraciones.extend(['jira', 'confluence', 'slack'])
        
        return integraciones
    
    def calcular_roi_proyectado(self, organizacion_id):
        org = self.obtener_organizacion(organizacion_id)
        if not org:
            return None
        
        empleados = org.get('empleados', 0)
        plan = org.get('plan', 'startup')
        
        # Costos estimados
        costos_mensuales = {
            'startup': 499,
            'business': 1999,
            'enterprise': 9999,
            'global': 25000
        }
        
        costo_anual = costos_mensuales.get(plan, 499) * 12
        
        # Beneficios estimados
        mejora_productividad = 0.30  # 30% promedio
        salario_promedio_anual = 60000  # USD
        ahorro_rotacion = empleados * 0.15 * salario_promedio_anual * 0.5  # 15% reducción rotación
        aumento_productividad = empleados * salario_promedio_anual * mejora_productividad
        
        beneficio_total = ahorro_rotacion + aumento_productividad
        roi = (beneficio_total - costo_anual) / costo_anual
        
        return {
            'costo_anual': costo_anual,
            'beneficio_total': beneficio_total,
            'roi': round(roi, 2),
            'payback_meses': round((costo_anual / beneficio_total) * 12, 1)
        }
    
    def obtener_organizacion(self, org_id):
        return next((o for o in self.organizaciones_activas if o['id'] == org_id), None)

mentalia_inst = MentaliaInstitucional()

@app.route('/')
def home():
    return {
        'mentalia_institucional': 'MENTALIA Institucional - Despliegue Empresarial ND',
        'version': '2.0 MENTALIA',
        'status': 'ACTIVE',
        'organizaciones_activas': mentalia_inst.stats['organizaciones_activas'],
        'roi_promedio': f"{mentalia_inst.stats['roi_promedio']*100:.0f}%",
        'ecosystem': 'MENTALIA'
    }

@app.route('/api/crear-organizacion', methods=['POST'])
def crear_organizacion():
    data = request.get_json()
    organizacion = mentalia_inst.crear_organizacion(data)
    return jsonify({
        'status': 'ORGANIZACION_CREADA',
        'organizacion': organizacion,
        'especializacion_nd': 'Primera plataforma empresarial específica para neurodivergencia'
    })

@app.route('/api/calcular-roi/<org_id>', methods=['GET'])
def calcular_roi(org_id):
    roi = mentalia_inst.calcular_roi_proyectado(org_id)
    if roi:
        return jsonify({
            'roi_proyectado': roi,
            'diferenciacion': 'ROI comprobado en transformación organizacional neurodiversa'
        })
    return jsonify({'error': 'Organización no encontrada'}), 404

@app.route('/api/stats', methods=['GET'])
def stats():
    return jsonify({
        'estadisticas': mentalia_inst.stats,
        'diferenciacion': 'Primera plataforma empresarial especializada en neurodiversidad',
        'impacto': 'Transformación organizacional a través de inclusión ND'
    })

if __name__ == '__main__':
    print("🏢 MENTALIA Institucional - Sistema activado")
    print("📊 Gestión empresarial ND: DISPONIBLE")
    print("💰 ROI promedio: 285%")
    app.run(host='0.0.0.0', port=5017, debug=True)

