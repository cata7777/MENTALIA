#!/bin/bash

# Ruta base del disco MENTALIA
BASE="/Volumes/MENTALIA"

echo "🟩 Iniciando configuración de entorno MENTALIA..."

# Crear estructura de carpetas
mkdir -p "$BASE/DEPLOYS/BLU"
mkdir -p "$BASE/DEPLOYS/COEFICIENTE_IA"
mkdir -p "$BASE/DEPLOYS/CREWAI"
mkdir -p "$BASE/MODELS"
mkdir -p "$BASE/SCRIPTS"
mkdir -p "$BASE/LOGS"
mkdir -p "$BASE/PITCH"
mkdir -p "$BASE/CONFIG"

# Mover archivos si existen en el directorio de ejecución
echo "📦 Moviendo archivos si están disponibles..."

if [ -f "./BLU_EVE_7D_DEPLOY.zip" ]; then
    mv "./BLU_EVE_7D_DEPLOY.zip" "$BASE/DEPLOYS/BLU/"
fi

if [ -f "./BLU_MODEL_ND_AI_DEPLOY.zip" ]; then
    mv "./BLU_MODEL_ND_AI_DEPLOY.zip" "$BASE/DEPLOYS/BLU/"
fi

if [ -f "./COEFICIENTE_IA_MODEL_DEPLOY.zip" ]; then
    mv "./COEFICIENTE_IA_MODEL_DEPLOY.zip" "$BASE/DEPLOYS/COEFICIENTE_IA/"
fi

if [ -f "./inference_mistral.py" ]; then
    mv "./inference_mistral.py" "$BASE/SCRIPTS/"
fi

if [ -f "./launch_mentalia_50bots.command" ]; then
    mv "./launch_mentalia_50bots.command" "$BASE/SCRIPTS/"
fi

if [ -f "./mistral-7b-instruct-v0.1.gguf" ]; then
    mv "./mistral-7b-instruct-v0.1.gguf" "$BASE/MODELS/"
fi

# Desactivar indexación
mdutil -i off "$BASE" >/dev/null 2>&1

# Crear log
echo "MENTALIA BOOT: $(date)" > "$BASE/LOGS/MENTALIA_BOOT.LOG"
echo "Estructura creada y archivos organizados correctamente." >> "$BASE/LOGS/MENTALIA_BOOT.LOG"

echo "✅ Estructura base del ecosistema MENTALIA desplegada con éxito."
