# ENDPOINTS_DISENA_CURSO_ND.py - contenido base del módulo disena_tu_curso
