# SSO_PERFIL_ND.py - contenido base del módulo cv
