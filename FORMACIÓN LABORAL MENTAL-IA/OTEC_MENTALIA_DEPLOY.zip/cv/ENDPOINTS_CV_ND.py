# ENDPOINTS_CV_ND.py - contenido base del módulo cv
