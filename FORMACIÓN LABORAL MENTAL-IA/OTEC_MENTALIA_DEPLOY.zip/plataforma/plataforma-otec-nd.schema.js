# plataforma-otec-nd.schema.js - contenido base del módulo plataforma
