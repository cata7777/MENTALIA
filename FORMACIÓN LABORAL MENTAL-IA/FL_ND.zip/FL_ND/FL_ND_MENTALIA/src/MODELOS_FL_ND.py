# MODELOS_FL_ND.py - módulo FL.ND
