# plataforma-otec-nd.schema.js - contenido del módulo PLATAFORMA_OTEC
