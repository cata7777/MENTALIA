# MODELOS_CV_ND.py - contenido del módulo CV_ND
